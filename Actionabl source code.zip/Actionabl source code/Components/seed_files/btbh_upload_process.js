const { constants } = global.modules;

const seedRows = {
    [constants.tableNames.CronSchedule]: [{
        name: 'BTBH Cron',
        time_slot: 'day',
        cron_config: [{
            cron_expression: "15 17 * * 1-5"
        }]
    }],

    [constants.tableNames.AutomationConnector]: [{
        id: 1081,
        category: constants.activityType.RPA,
        type: constants.automationType.ActionablRPA,
        name: 'Stop Fos Hold',
        config_dat: {
            script_type: constants.rpaType.CustomRPA,
            script_name: 'custom/stop_hold_fos.js',
            app_path: '\\\\10.179.3.150\\prcsnsow_hexa\\sp_64.exe',
            app_user: 'UOPS',
            app_password: 'Hsl@4444'
        },
    },
    {
        id: 1082,
        category: constants.activityType.RPA,
        type: constants.automationType.ActionablRPA,
        name: 'Net Banking Download',
        retry_count: 1,
        config_dat: {
            script_type: constants.rpaType.WebRPA,
            script_name: 'Web/rule/net_banking_download.js',
            app_path: 'https://netbanking.hdfcbank.com/netbanking/',
            script_params: [
                { key: 'cust_id', value: '27329787' },
                { key: 'main_cust_id', value: '756578' },
                { key: 'merch_cust_id', value: '11016510' },
                { key: 'password_cust', value: 'GANESH888' },
                { key: 'password_main_cust', value: 'HSL@3333' },
                { key: 'password_merch_cust', value: 'Hsl@4444' }
            ]
        },
    },
    {
        id: 1083,
        category: constants.activityType.Bot,
        type: constants.automationType.SendEmail,
        name: 'Send Download Status Mail',
        icon: 'Email.svg',
        icon_type: 1,
        config_dat: {
            email_account: 181,
            email_template: 183,
            email_type: 2
        },
    },
    {
        id: 1084,
        category: constants.activityType.RPA,
        type: constants.automationType.ActionablRPA,
        name: 'Remove 82950 ',
        config_dat: {
            script_type: constants.rpaType.CustomRPA,
            script_name: 'custom/remove_82950.js',
            script_params: []
        },
    },
    {
        id: 1085,
        category: constants.activityType.RPA,
        type: constants.automationType.ActionablRPA,
        name: 'Stop Fos Hold Receipt',
        config_dat: {
            script_type: constants.rpaType.CustomRPA,
            script_name: 'custom/hold_receipt.js',
            app_path: '\\\\10.179.3.150\\prcsnsow_hexa\\sp_64.exe',
            app_user: 'UOPS',
            app_password: 'Hsl@4444'
        },
    },
    {
        id: 1086,
        category: constants.activityType.Bot,
        type: constants.automationType.SendEmail,
        name: 'Send Mail to DPC Team',
        icon: 'Email.svg',
        icon_type: 1,
        config_dat: {
            email_account: 181,
            email_template: 182,
            email_type: 2
        },
    },
    {
        id: 1087,
        category: constants.activityType.RPA,
        type: constants.automationType.ActionablRPA,
        name: 'File Transfer',
        config_dat: {
            script_type: constants.rpaType.CustomRPA,
            script_name: 'custom/file_transfer.js',
            app_path: '\\\\10.179.3.150\\prcsnsow_hexa\\sp_64.exe',
            app_user: 'UOPS',
            app_password: 'Hsl@4444',
            script_params: []
        },
    },
    {
        id: 1088,
        category: constants.activityType.RPA,
        type: constants.automationType.ActionablRPA,
        name: 'MB Fund Settlement',
        config_dat: {
            script_type: constants.rpaType.CustomRPA,
            script_name: 'custom/fund_settlement.js',
            app_path: '\\\\10.179.3.150\\prcsnsow_hexa\\sp_64.exe',
            app_user: 'UOPS',
            app_password: 'Hsl@4444',
            script_params: []
        },
    },
    {
        id: 1089,
        category: constants.activityType.Bot,
        type: constants.automationType.SendEmail,
        name: 'Send Merchant Banking Status Mail',
        icon: 'Email.svg',
        icon_type: 1,
        config_dat: {
            email_account: 181,
            email_template: 184,
            email_type: 2
        },
    },
    {
        id: 1090,
        category: constants.activityType.RPA,
        type: constants.automationType.ActionablRPA,
        name: 'BT Fund Settlement',
        config_dat: {
            script_type: constants.rpaType.CustomRPA,
            script_name: 'custom/BT_fund_settlement.js',
            app_path: '\\\\10.179.3.150\\prcsnsow_hexa\\sp_64.exe',
            app_user: 'UOPS',
            app_password: 'Hsl@4444',
            script_params: []
        },
    },
    {
        id: 1091,
        category: constants.activityType.RPA,
        type: constants.automationType.ActionablRPA,
        name: 'BH Fund Settlement',
        config_dat: {
            script_type: constants.rpaType.CustomRPA,
            script_name: 'custom/BH_fund_settlement.js',
            app_path: '\\\\10.179.3.150\\prcsnsow_hexa\\sp_64.exe',
            app_user: 'UOPS',
            app_password: 'Hsl@4444',
            script_params: []
        },
    },
    {
        id: 1092,
        category: constants.activityType.Bot,
        type: constants.automationType.SendEmail,
        name: 'Send BTBH Upload Status Mail',
        icon: 'Email.svg',
        icon_type: 1,
        config_dat: {
            email_account: 181,
            email_template: 185,
            email_type: 2
        },
    },
    ],

    //cron_schedule: '0 16 * * 1-5' (start at 4pm monday to friday)
    [constants.tableNames.AutomationManager]: [
        { id: 1080, automation_id: constants.automationConnector.cron, proc_def_key: 'btbh_upload_process', task_key: 'cron_start', execution_mode: constants.automationExecutionMode.Recurrent, cron_schedule: 1 },
        { id: 1081, automation_id: 1081, proc_def_key: 'btbh_upload_process', task_key: 'stop_fos_hold', execution_mode: constants.automationExecutionMode.Call },
        { id: 1082, automation_id: 1082, proc_def_key: 'btbh_upload_process', task_key: 'net_banking_download', execution_mode: constants.automationExecutionMode.Call },
        { id: 1083, automation_id: 1083, proc_def_key: 'btbh_upload_process', task_key: 'download_status_mail', execution_mode: constants.automationExecutionMode.Call },
        { id: 1084, automation_id: 1084, proc_def_key: 'btbh_upload_process', task_key: 'remove_82950', execution_mode: constants.automationExecutionMode.Call },
        { id: 1085, automation_id: 1085, proc_def_key: 'btbh_upload_process', task_key: 'stop_fos_hold_receipt', execution_mode: constants.automationExecutionMode.Call },
        { id: 1086, automation_id: 1086, proc_def_key: 'btbh_upload_process', task_key: 'dcp_team_mail', execution_mode: constants.automationExecutionMode.Call },
        { id: 1087, automation_id: 1087, proc_def_key: 'btbh_upload_process', task_key: 'file_transfer', execution_mode: constants.automationExecutionMode.Call },
        { id: 1088, automation_id: 1088, proc_def_key: 'btbh_upload_process', task_key: 'mb_fund_settlement', execution_mode: constants.automationExecutionMode.Call },
        { id: 1089, automation_id: 1089, proc_def_key: 'btbh_upload_process', task_key: 'merchant_banking_status_email', execution_mode: constants.automationExecutionMode.Call },
        { id: 1090, automation_id: 1090, proc_def_key: 'btbh_upload_process', task_key: 'bt_fund_settlement', execution_mode: constants.automationExecutionMode.Call },
        { id: 1091, automation_id: 1091, proc_def_key: 'btbh_upload_process', task_key: 'bh_fund_settlement', execution_mode: constants.automationExecutionMode.Call },
        { id: 1092, automation_id: 1092, proc_def_key: 'btbh_upload_process', task_key: 'btbh_upload_status_mail', execution_mode: constants.automationExecutionMode.Call }
    ],

    [constants.tableNames.DataSourceDef]: [
        [181, 'Run Time Decision Def', constants.dataSourceCategory.DMN, [
            { field_name: "run_date", field_title: "Run Date", type: constants.fieldType.Date, input: true },
            { field_name: "start_date", field_title: "Start Date", type: constants.fieldType.Date },
            { field_name: "start_time", field_title: "Start Time", type: constants.fieldType.Time },
            { field_name: "end_date", field_title: "End Date", type: constants.fieldType.Date },
            { field_name: "end_time", field_title: "End Time", type: constants.fieldType.Time }
        ]],
    ],

    [constants.tableNames.DataSource]: [
        [181, 181, 'Run Time Decision', constants.dataSourceType.Entry, [{
            "run_date": 1625337000000,
            "start_date": 1625337000000,
            "start_time": 23400000,
            "end_date": 1625423400000,
            "end_time": 41400000
        },
        {
            "run_date": 1625509800000,
            "start_date": 1625250600000,
            "start_time": 34200000,
            "end_date": 1625509800000,
            "end_time": 41400000
        },
        {
            "start_time": 42000000,
            "end_time": 42000000
        }
        ]],
    ],

    [constants.tableNames.Field]: [
        { id: 'main_folder', type: constants.fieldType.String, name: 'Main Folder' },
        { id: 'start_date', type: constants.fieldType.Date, name: 'Start Date' },
        { id: 'start_time', type: constants.fieldType.Time, name: 'Start Time' },
        { id: 'end_date', type: constants.fieldType.Date, name: 'End Date' },
        { id: 'end_time', type: constants.fieldType.Time, name: 'End Time' },
        { id: 'stop_fos_hold_complete', type: constants.fieldType.Boolean, name: 'Stop Fos Hold Complete' },
        { id: 'stop_fos_hold_receipt_complete', type: constants.fieldType.Boolean, name: 'Stop Fos Hold Receipt Complete' },
        { id: 'download_complete', type: constants.fieldType.Boolean, name: 'All Download Complete' },
        { id: 'remove_82950_complete', type: constants.fieldType.Boolean, name: 'Remove 82950 Complete' },
        { id: 'file_transfer_complete', type: constants.fieldType.Boolean, name: 'File Transfer Complete' },
        { id: 'merchant_upload_complete', type: constants.fieldType.Boolean, name: 'Merchant File Upload Complete' },
        { id: 'bt_upload_complete', type: constants.fieldType.Boolean, name: 'BT File Upload Complete' },
        { id: 'bh_upload_complete', type: constants.fieldType.Boolean, name: 'BH File Upload Complete' },
        { id: 'upload_complete', type: constants.fieldType.Boolean, name: 'All Upload Complete' },
        { id: 'skip_stop_fos_hold', type: constants.fieldType.Boolean, name: 'Skip Stop FOS Hold' },
        { id: 'skip_stop_fos_hold_receipt', type: constants.fieldType.Boolean, name: 'Skip Stop FOS Hold Receipt' },
        { id: 'skip_net_banking_download', type: constants.fieldType.Boolean, name: 'Skip Net Banking Download' },
        { id: 'skip_remove_82950', type: constants.fieldType.Boolean, name: 'Skip Remove 82950' },
        { id: 'skip_file_transfer', type: constants.fieldType.Boolean, name: 'Skip File Transfer' },
        { id: 'skip_mb_fund_settlement', type: constants.fieldType.Boolean, name: 'Skip MB Fund Settlement' },
        { id: 'skip_bt_fund_settlement', type: constants.fieldType.Boolean, name: 'Skip BT Fund Settlement' },
        { id: 'skip_bh_fund_settlement', type: constants.fieldType.Boolean, name: 'Skip BH Fund Settlement' },
        { id: 'client_id', type: constants.fieldType.String, name: 'Client Id' },
        { id: 'client_name', type: constants.fieldType.String, name: 'Client Name' },
        { id: 'merchant_ref_no', type: constants.fieldType.String, name: 'Merchant Ref No.' },
        { id: 'bo_amount', type: constants.fieldType.String, name: 'BO Amount' },
        { id: 'bank_amount', type: constants.fieldType.String, name: 'Bank Amount' },
        { id: 'account_no', type: constants.fieldType.String, name: 'Account No' },
        { id: 'failure_reason', type: constants.fieldType.String, name: 'Failure Reason' },
        {
            id: 'file_status',
            type: constants.fieldType.String,
            name: 'File Status',
            control_type: constants.fieldControlType.Dropdown,
            config_dat: {
                values: [{ display: 'Download Error', value: 'Download Error' }, { display: 'Upload Error', value: 'Upload Error' },
                { display: 'Downloaded Successfully', value: 'Downloaded Successfully' }, { display: 'Uploaded Successfully', value: 'Uploaded Successfully' }
                ],
                default: null
            }
        },
        {
            id: 'btbh_files',
            type: constants.fieldType.FieldSet,
            name: 'BTBH Files',
            is_list: true,
            config_dat: [
                { id: 'file_name' }, { id: 'file_status' }, { id: 'message' }
            ]
        },
        {
            id: 'mb_email_table',
            type: constants.fieldType.FieldSet,
            name: 'MB Email Table',
            is_list: true,
            config_dat: [
                { id: 'client_id' }, { id: 'client_name' }, { id: 'merchant_ref_no' }, { id: 'bo_amount' }, { id: 'bank_amount' }, { id: 'account_no' }, { id: 'failure_reason' }
            ]
        }
    ],

    [constants.tableNames.Rule]: [
        [1081, constants.ruleCategory.General, constants.ruleType.Condition, 'Stop Fos Hold Complete', [
            { condition: '$.stop_fos_hold_complete !== true', action: 'throw "Could not complete Stop Fos Hold"' }
        ]],
        [1082, constants.ruleCategory.General, constants.ruleType.Condition, 'Merchant File Upload Complete', [
            { condition: '$.merchant_upload_complete !== true', action: 'throw "Could not upload merchant file"' }
        ]],
        [1083, constants.ruleCategory.General, constants.ruleType.JavaScript, 'Attach Merchant Process log', {
            script: "$.attachments = [ { filename: 'Merchant_Process_log.xlsx', path: $.main_folder + '/MB/Merchant_Process_log.xlsx' } ]"
        }],
        [1084, constants.ruleCategory.General, constants.ruleType.JavaScript, 'Create Status List', {
            script: "let files = $.btbh_files;\r\nlet statusList = [];\r\nif (files != null) {\r\n    for (let file of files) {\r\n        let status = { 'File Name': file.file_name, 'Status': file.file_status };\r\n        if (file.message != null) status.Error = file.message;\r\n        statusList.push(status);\r\n    }\r\n    $.btbh_files = statusList;\r\n}"
        }],
        [1085, constants.ruleCategory.General, constants.ruleType.Condition, 'Reset Retry', [
            { condition: '$.retry != null', action: '$.retry == null' }
        ]],
        [1086, constants.ruleCategory.General, constants.ruleType.Condition, 'Manual Download Complete', [
            { condition: '$.download_complete !== true && $.retry !== true', action: 'throw "Complete the download manually OR retry the download"' }
        ]],
        [1087, constants.ruleCategory.General, constants.ruleType.Condition, 'Manual Upload Complete', [
            { condition: '!(($.bt_upload_complete === true && $.bh_upload_complete === true) || $.retry === true)', action: 'throw "Complete the upload manually OR retry the download"' }
        ]],
        [1088, constants.ruleCategory.General, constants.ruleType.JavaScript, 'Determine Download Times', {
            script: `if ($.run_date == null) {
    $.run_date = Date.now();
}

let runDate = $.run_date;

if ($.start_date == null) {
    let dt = new Date(runDate);
    let dayNo = dt.getDay();

    if (dayNo == 1) {
        dt.setDate(dt.getDate() - 3);
    } else if (dayNo == 0) {
        dt.setDate(dt.getDate() - 2);
    } else {
        dt.setDate(dt.getDate() - 1);
    }
    $.start_date = dt;
}

if ($.end_date == null) {
    $.end_date = runDate;
}

let dt = new Date($.end_date);
let day = dt.getDate();
if (day <= 9) day = '0' + day;
let month = (dt.getMonth() + 1);
if (month <= 9) month = '0' + month;
let year = dt.getFullYear();
let endDt = year + '-' + month + '-' + day;

let rslt = await modules.bfs.ensureFolder($.main_folder);
if (rslt.rc != 0) {
    throw rslt.msg;
}

console.log('run_date ' + new Date($.run_date));
console.log('start_date ' + new Date($.start_date));
console.log('end_date ' + new Date($.end_date));
console.log('main_folder ' + $.main_folder);`
        }],
        [1089, constants.ruleCategory.General, constants.ruleType.JavaScript, 'Check Start Parameters', {
            script: `if ($.start_date != null) {
    let messages = [];
    if ($.start_time == null) messages.push('Start Time is required');
    if ($.end_date == null) messages.push('End Date is required');
    if ($.end_time == null) messages.push('End Time is required');
    if (messages.length > 0) $.messages = messages;
}`
        }]
    ],

    [constants.tableNames.Record]: [
        /*
        [181, constants.recordType.EmailAccount, 'BTBH Email Account', {
            "host": "imap.gmail.com", "port": 993, "user": "btbh.process@gmail.com", "password": "Prescient#1",
            "smtp_host": "smtp.gmail.com", "smtp_port": 465, "tls": true, "ssl": true
        }],
        */
        [181, constants.recordType.EmailAccount, 'BTBH Email Account', {
            "host": "10.176.4.16",
            "port": 993,
            "user": "onlineops@hdfcsesc.com",
            "password": null,
            "smtp_host": "10.176.4.16",
            "smtp_port": 25,
            "tls": false,
            "ssl": false
        }],

        [182, constants.recordType.EmailTemplate, 'DPC Team Mail', {
            recipient_email: 'btbh.process@gmail.com',
            cc_email: 'keval.juthani@actionabl.ai',
            email_subject: 'Run Matrix EOD Process',
            recipient_name: "All",
            intro: [{ value: "Kindly proceed with Matrix EOD process" }],
            html_email: true
        }],
        [183, constants.recordType.EmailTemplate, 'Download Status Mail', {
            recipient_email: 'btbh.process@gmail.com',
            email_subject: 'BTBH download status for {{data_format:dd-MM-yyyy}}',
            recipient_name: "All",
            intro: [{ value: "Please see below the BTBH download status for {{data_format:dd-MM-yyyy}}." }],
            outro: [{ value: "All files downloaded successfully? : {{download_complete}}" }],
            table: '{{btbh_files}}',
            html_email: true
        }],
        [184, constants.recordType.EmailTemplate, 'Merchant Banking Status Mail', {
            recipient_email: 'keval.juthani@actionabl.ai',
            email_subject: 'Merchant Banking Receipt Entry',
            recipient_name: "All",
            intro: [
                { value: "Today there was mismatch in Merchant Bank Reconciliation." },
                { value: "Request you to please pass receipt entry for same as per attached detail" }
            ],
            table: '{{mb_email_table}}',
            html_email: true
        }],
        [185, constants.recordType.EmailTemplate, 'BTBH Upload Status Mail', {
            recipient_email: 'keval.juthani@actionabl.ai',
            email_subject: 'BTBH upload status for {{data_format:dd-MM-yyyy}}',
            recipient_name: "All",
            intro: [{ value: "Please see below the BTBH upload status for {{data_format:dd-MM-yyyy}}" }],
            outro: [
                { value: "BT files uploaded successfully? : {{bt_upload_complete}}" },
                { value: "BH files uploaded successfully? : {{bh_upload_complete}}" }
            ],
            html_email: true
        }]
    ],
};

module.exports = { seedRows };