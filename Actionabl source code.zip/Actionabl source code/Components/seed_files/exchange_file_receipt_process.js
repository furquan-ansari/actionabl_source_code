const { constants } = global.modules;

const seedRows = {
    [constants.tableNames.AutomationConnector]: [{
        "id": 6001,
        "category": 5,
        "type": 101,
        "name": "EFR BSE Initial Status",
        "config_dat": {
            "script_type": "4",
            "script_name": "custom/efr_initial_status.js",
            "script_params": [{
                "key": "category",
                "value": "bse"
            }]
        }
    },
    {
        "id": 6002,
        "category": 5,
        "type": 101,
        "name": "EFR BSE Bhavcopy",
        "config_dat": {
            "script_type": "1",
            "script_name": "Web/rule/efr_bse_bhavcopy.js",
            "app_path": "https://www.bseindia.com/markets/MarketInfo/BhavCopy.aspx",
            "browser_params": {
                "browser_type": "chromium"
            },
            "script_params": []
        }
    },
    {
        "id": 6011,
        "category": 5,
        "type": 101,
        "name": "EFR BSE Member Initial Status",
        "config_dat": {
            "script_type": "4",
            "script_name": "custom/efr_initial_status.js",
            "script_params": [{
                "key": "category",
                "value": "bse_member"
            }]
        }
    },
    {
        "id": 6012,
        "category": 5,
        "type": 101,
        "name": "EFR BSE Member",
        "config_dat": {
            "script_type": "1",
            "script_name": "Web/rule/efr_bse_member.js",
            "app_path": "https://member.bseindia.com/",
            "browser_params": {
                "browser_type": "firefox"
            },
            "script_params": [{
                "key": "userId",
                "value": "0393"
            },
            {
                "key": "memberId",
                "value": "0393"
            },
            {
                "key": "password",
                "value": "Hdfc@1111"
            }
            ]
        }
    },
    {
        "id": 6021,
        "category": 5,
        "type": 101,
        "name": "EFR NSE Member Login1 Initial Status",
        "config_dat": {
            "script_type": "4",
            "script_name": "custom/efr_initial_status.js",
            "script_params": [{
                "key": "category",
                "value": "nse_member_login1"
            }]
        }
    },
    {
        "id": 6022,
        "category": 5,
        "type": 101,
        "name": "EFR NSE Member Login1",
        "config_dat": {
            "script_type": "1",
            "script_name": "Web/rule/efr_nse_member_login1.js",
            "app_path": "https://ims.connect2nsccl.com/MemberPortal/",
            "browser_params": {
                "browser_type": "firefox"
            },
            "script_params": [{
                "key": "userId1",
                "value": "ROHITGEXC"
            },
            {
                "key": "memberId1",
                "value": "11094"
            },
            {
                "key": "password1",
                "value": "Hdfc@12345678"
            }
            ]
        }
    },
    {
        "id": 6031,
        "category": 5,
        "type": 101,
        "name": "EFR NSE Member Login2 Initial Status",
        "config_dat": {
            "script_type": "4",
            "script_name": "custom/efr_initial_status.js",
            "script_params": [{
                "key": "category",
                "value": "nse_member_login2"
            }]
        }
    },
    {
        "id": 6032,
        "category": 5,
        "type": 101,
        "name": "EFR NSE Member Login2",
        "config_dat": {
            "script_type": "1",
            "script_name": "Web/rule/efr_nse_member_login2.js",
            "app_path": "https://ims.connect2nsccl.com/MemberPortal/",
            "browser_params": {
                "browser_type": "firefox"
            },
            "script_params": [{
                "key": "userId2",
                "value": "ROHITGEXF"
            },
            {
                "key": "memberId2",
                "value": "11094"
            },
            {
                "key": "password2",
                "value": "Hdfcsec@2222"
            }
            ]
        }
    },
    {
        "id": 6041,
        "category": 5,
        "type": 101,
        "name": "EFR NSE Member Login3 Initial Status",
        "config_dat": {
            "script_type": "4",
            "script_name": "custom/efr_initial_status.js",
            "script_params": [{
                "key": "category",
                "value": "nse_member_login3"
            }]
        }
    },
    {
        "id": 6042,
        "category": 5,
        "type": 101,
        "name": "EFR NSE Member Login3",
        "config_dat": {
            "script_type": "1",
            "script_name": "Web/rule/efr_nse_member_login3.js",
            "app_path": "https://ims.connect2nsccl.com/MemberPortal/",
            "browser_params": {
                "browser_type": "firefox"
            },
            "script_params": [{
                "key": "userId3",
                "value": "ROHITGEXX"
            },
            {
                "key": "memberId3",
                "value": "11094"
            },
            {
                "key": "password3",
                "value": "Hdf@1234"
            }
            ]
        }
    },
    {
        "id": 6051,
        "category": 5,
        "type": 101,
        "name": "EFR NSE All Reports Initial Status",
        "config_dat": {
            "script_type": "4",
            "script_name": "custom/efr_initial_status.js",
            "script_params": [{
                "key": "category",
                "value": "nse_allReports"
            }]
        }
    },
    {
        "id": 6052,
        "category": 5,
        "type": 101,
        "name": "EFR NSE All Reports",
        "config_dat": {
            "script_type": "1",
            "script_name": "Web/rule/efr_nse_allReports.js",
            "app_path": "https://www.nseindia.com/all-reports",
            "browser_params": {
                "browser_type": "firefox"
            },
            "script_params": []
        }
    },
    {
        "id": 6061,
        "category": 5,
        "type": 101,
        "name": "EFR MCX Initial Status",
        "config_dat": {
            "script_type": "4",
            "script_name": "custom/efr_initial_status.js",
            "script_params": [{
                "key": "category",
                "value": "mcx"
            }]
        }
    },
    {
        "id": 6062,
        "category": 5,
        "type": 101,
        "name": "EFR MCX",
        "config_dat": {
            "script_type": "1",
            "script_name": "Web/rule/efr_mcx.js",
            "app_path": "https://sftp.mcxindia.com/",
            "browser_params": {
                "browser_type": "chromium"
            },
            "script_params": [{
                "key": "userId",
                "value": "56015"
            },
            {
                "key": "memberId",
                "value": "Risk@7777"
            }
            ]
        }
    }
    ],

    [constants.tableNames.AutomationManager]: [{
        "id": 6001,
        "automation_id": 6001,
        "proc_def_key": "exchange_files_receipt_bse",
        "task_key": "initial_status",
        "execution_mode": 1
    },
    {
        "id": 6002,
        "automation_id": 6002,
        "proc_def_key": "exchange_files_receipt_bse",
        "task_key": "rpa_task",
        "execution_mode": 1
    },
    {
        "id": 6011,
        "automation_id": 6011,
        "proc_def_key": "exchange_files_receipt_bse_member",
        "task_key": "initial_status",
        "execution_mode": 1
    },
    {
        "id": 6012,
        "automation_id": 6012,
        "proc_def_key": "exchange_files_receipt_bse_member",
        "task_key": "rpa_task",
        "execution_mode": 1
    },
    {
        "id": 6021,
        "automation_id": 6021,
        "proc_def_key": "exchange_files_receipt_nse_member_login1",
        "task_key": "initial_status",
        "execution_mode": 1
    },
    {
        "id": 6022,
        "automation_id": 6022,
        "proc_def_key": "exchange_files_receipt_nse_member_login1",
        "task_key": "rpa_task",
        "execution_mode": 1
    },
    {
        "id": 6031,
        "automation_id": 6031,
        "proc_def_key": "exchange_files_receipt_nse_member_login2",
        "task_key": "initial_status",
        "execution_mode": 1
    },
    {
        "id": 6032,
        "automation_id": 6032,
        "proc_def_key": "exchange_files_receipt_nse_member_login2",
        "task_key": "rpa_task",
        "execution_mode": 1
    },
    {
        "id": 6041,
        "automation_id": 6041,
        "proc_def_key": "exchange_files_receipt_nse_member_login3",
        "task_key": "initial_status",
        "execution_mode": 1
    },
    {
        "id": 6042,
        "automation_id": 6042,
        "proc_def_key": "exchange_files_receipt_nse_member_login3",
        "task_key": "rpa_task",
        "execution_mode": 1
    },
    {
        "id": 6051,
        "automation_id": 6051,
        "proc_def_key": "exchange_files_receipt_nse_allReports",
        "task_key": "initial_status",
        "execution_mode": 1
    },
    {
        "id": 6052,
        "automation_id": 6052,
        "proc_def_key": "exchange_files_receipt_nse_allReports",
        "task_key": "rpa_task",
        "execution_mode": 1
    },
    {
        "id": 6061,
        "automation_id": 6061,
        "proc_def_key": "exchange_files_receipt_mcx",
        "task_key": "initial_status",
        "execution_mode": 1
    },
    {
        "id": 6062,
        "automation_id": 6062,
        "proc_def_key": "exchange_files_receipt_mcx",
        "task_key": "rpa_task",
        "execution_mode": 1
    }
    ],

    [constants.tableNames.Field]: [{
        "id": "test_current_datetime",
        "name": "Test - Current Date Time",
        "type": "6",
        "config_dat": {}
    },
    {
        "id": "efr_run_rpa",
        "name": "EFR Run RPA ?",
        "type": "4",
        "config_dat": {}
    },
    {
        "id": "efr_param_str",
        "name": "EFR Parameter String",
        "type": "1",
        "config_dat": {}
    }
    ],
};

module.exports = { seedRows };