const { constants } = global.modules;

const seedRows = {
    [constants.tableNames.CronSchedule]: [
        {
            name: 'Margin Pledge Download Cron',
            time_slot: 'day',
            cron_config: [
                {
                    cron_expression: "0,30 9-16 * * 1-5"
                }
            ]
        }
    ],

    [constants.tableNames.AutomationConnector]: [
        {
            id: 1501,
            category: constants.activityType.RPA,
            type: constants.automationType.ActionablRPA,
            name: 'Margin Pledge Copy Files',
            config_dat: {
                script_type: constants.rpaType.CustomRPA,
                script_name: 'custom/Margin Pledge and Email Process/copy_files.js',
            },
        },
        {
            id: 1502,
            category: constants.activityType.RPA,
            type: constants.automationType.ActionablRPA,
            name: 'Margin Pledge Encryption',
            config_dat: {
                script_type: constants.rpaType.CustomRPA,
                script_name: 'custom/Margin Pledge and Email Process/encrypt_files.js',
                app_path: 'D:\\Bombus\\Client\\Hdfc\\DummyData\\KCSApps\\Lib\\DIGISIGN\\EncryptHRRTFile.exe'
            },
        },
        {
            id: 1503, category: constants.activityType.Bot, type: constants.automationType.Ftp, name: 'Margin Pledge Ftp', icon: 'Ftp.svg', icon_type: 1,
            config_dat: {
                ftp_site: 191, num_retry: null, retry_interval: null, cutoff_time: 18, ftp_commands: [
                    {
                        command_type: 2, ftp_folder: '/HRT/HRP/{{data_format:MMM-yyyy}}/{{data_format:dd-MM-yyyy}}', local_folder: 'D:\\Bombus\\Client\\Hdfc\\DummyData\\KCSApps\\Lib\\DIGISIGN\\Encrypt', files: [
                            { name: 'NPHS{{data_format:yyMMdd}}', required: true },
                            { name: 'CPHS{{data_format:yyMMdd}}', required: true },
                            { name: 'Annexure_{{data_format:yyyyMMdd}}', required: true }
                        ]
                    }
                ]
            },
        },
        {
            id: 1504,
            category: constants.activityType.RPA,
            type: constants.automationType.ActionablRPA,
            name: 'Margin Pledge Move Files',
            config_dat: {
                script_type: constants.rpaType.CustomRPA,
                script_name: 'custom/Margin Pledge and Email Process/move_files.js',
            },
        },
        {
            id: 1505,
            category: constants.activityType.Bot,
            type: constants.automationType.SendEmail,
            name: 'Send Margin Pledge Status Mail',
            icon: 'Email.svg',
            icon_type: 1,
            config_dat: {
                email_account: 192,
                email_template: 193,
                email_type: 2
            },
        },
    ],

    [constants.tableNames.AutomationManager]: [
        { id: 1500, automation_id: constants.automationConnector.cron, proc_def_key: 'margin_pledge_download_process', task_key: 'cron_start', execution_mode: constants.automationExecutionMode.Recurrent, cron_schedule: 1 },
        { id: 1501, automation_id: 1501, proc_def_key: 'margin_pledge_download_process', task_key: 'copy_files', execution_mode: constants.automationExecutionMode.Call },
        { id: 1502, automation_id: 1502, proc_def_key: 'margin_pledge_download_process', task_key: 'encrypt_files', execution_mode: constants.automationExecutionMode.Call },
        { id: 1503, automation_id: 1503, proc_def_key: 'margin_pledge_download_process', task_key: 'send_files', execution_mode: constants.automationExecutionMode.Call },
        { id: 1504, automation_id: 1504, proc_def_key: 'margin_pledge_download_process', task_key: 'move_files', execution_mode: constants.automationExecutionMode.Call },
        { id: 1505, automation_id: 1505, proc_def_key: 'margin_pledge_download_process', task_key: 'send_mail', execution_mode: constants.automationExecutionMode.Call }
    ],

    [constants.tableNames.Field]: [
        { id: 'pledge_repledge_folder', type: constants.fieldType.String, name: 'Pledge Repledge Folder' },
        { id: 'digisign_folder', type: constants.fieldType.String, name: 'DIGISIGN Folder' },
        { id: 'copy_files_complete', type: constants.fieldType.Boolean, name: 'Copy Files Complete' },
        { id: 'encrypt_complete', type: constants.fieldType.Boolean, name: 'Encrypt Complete' },
        { id: 'send_files_complete', type: constants.fieldType.Boolean, name: 'Send Files Complete' },
        { id: 'move_files_complete', type: constants.fieldType.Boolean, name: 'Move Files Complete' },
        { id: 'upload_complete', type: constants.fieldType.Boolean, name: 'All Upload Complete' },
        { id: 'skip_copy_files', type: constants.fieldType.Boolean, name: 'Skip Copy Files' },
        { id: 'skip_encrypt_files', type: constants.fieldType.Boolean, name: 'Skip Encrypt Files' },
        { id: 'skip_send_files', type: constants.fieldType.Boolean, name: 'Skip Send Files' },
        { id: 'skip_move_files', type: constants.fieldType.Boolean, name: 'Skip Move Files' },
        {
            id: 'mp_files',
            type: constants.fieldType.FieldSet,
            name: 'MP Files',
            is_list: true,
            config_dat: [
                { id: 'file_name' }
            ]
        }
    ],

    [constants.tableNames.Rule]: [
        [1501, constants.ruleCategory.General, constants.ruleType.Expressions, 'Copy Files Complete', [
            { condition: '$.copy_files_complete !== true', result: 'throw "Could not complete copy files"' }
        ]],
        [1502, constants.ruleCategory.General, constants.ruleType.Expressions, 'Encrypt Files Complete', [
            { condition: '$.encrypt_files_complete !== true', result: 'throw "Could not complete encrypt files"' }
        ]],
        [1503, constants.ruleCategory.General, constants.ruleType.Expressions, 'Send Files Complete', [
            { condition: '$.send_files_complete !== true', result: 'throw "Could not complete send files"' }
        ]],
        [1504, constants.ruleCategory.General, constants.ruleType.Expressions, 'Move Files Complete', [
            { condition: '$.move_files_complete !== true', result: 'throw "Could not complete move files"' }
        ]],
    ],

    [constants.tableNames.Record]: [
        [191, constants.recordType.FtpSite, 'HDFC Margin Pledge FTP', {
            host: "efg.hdfcbank.com", port: 22, app_user: "CHSL_HRT", app_password: "Hsl@1111", api: 1, protocol: 2
        }],

        [192, constants.recordType.EmailAccount, 'Keval Prescient Email Account', {
            "host": "zopop.logix.in", "port": 995, "user": "keval.juthani@prescientinfotech.com", "password": "Prescient#7",
            "smtp_host": "smtp.logix.in", "smtp_port": 587, "tls": true, "ssl": false
        }],


        /*
        [192, constants.recordType.EmailAccount, 'BTBH Email Account', {
            "host": "10.176.4.16",
            "port": 993,
            "user": "onlineops@hdfcsesc.com",
            "password": null,
            "smtp_host": "10.176.4.16",
            "smtp_port": 25,
            "tls": false,
            "ssl": false
        }],
        */


        [193, constants.recordType.EmailTemplate, 'Margin Pledge Download Status Mail', {
            recipient_email: 'keval.juthani@actionabl.ai',
            email_subject: 'Margin Pledge Download Status for {{data_format:dd-MM-yyyy}}',
            recipient_name: "All",
            intro: [{ value: "Following files have been shared via SFTP:" }],
            table: '{{mp_files}}',
            html_email: true
        }]
    ],

}

module.exports = { seedRows };