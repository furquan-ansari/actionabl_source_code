const { util } = global.modules;
const modules = global.modules;
const { CustomRPABase, winAppDriver, Excel } = modules;
const { WinAppDriver, keyCode } = winAppDriver;

class customRPA extends CustomRPABase {
  async process() {
    let self = this;
    let params = self.$;
    let rslt;

    try {
      let appDriver = new WinAppDriver();
      rslt = await appDriver.connect({
        executablePath:
          "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
      });
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      // Open the website link
      /*   rslt = await appDriver.launchApp({
          appId: "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe", // Path to the browser executable
          arguments: ['https://rpachallenge.com/assets/rpaStockMarket/index.html'] // URL to open
        });
        if (rslt.rc != 0) return rslt; */

      rslt = await appDriver.setValue({
        selector: { automationId: "view_1021", name: "Address and search bar" },
        value: "https://rpachallenge.com/assets/rpaStockMarket/index.html",
        refresh: true,
      });
      if (rslt.rc != 0) return rslt;

      await util.wait(2000);

      rslt = await appDriver.sendKey({
        hwnd: appDriver.handle,
        key: keyCode.VK_RETURN,
      });
      if (rslt.rc != 0) return rslt;

      await util.wait(2000);

      // Assuming you have a function or mechanism to check the value of rslt.rc

      for (let i = 1; i <= 3; i++) {
        rslt = await appDriver.expand({
          selector: { automationId: "country" },
          refresh: true,
        });
        if (rslt.rc != 0) return rslt;

        // await util.wait(2000);

        rslt = await appDriver.sendKey({
          hwnd: appDriver.handle,
          key: keyCode.VK_DOWN,
        });
        if (rslt.rc != 0) return rslt;

        // await util.wait(2000);

        rslt = await appDriver.sendKey({
          hwnd: appDriver.handle,
          key: keyCode.VK_RETURN,
        });
        if (rslt.rc != 0) return rslt;

        // await util.wait(2000);

        rslt = await appDriver.sendKey({
          hwnd: appDriver.handle,
          key: keyCode.VK_TAB,
        });
        if (rslt.rc != 0) return rslt;

        // await util.wait(2000);

        rslt = await appDriver.sendKey({
          hwnd: appDriver.handle,
          key: keyCode.VK_RETURN,
        });
        if (rslt.rc != 0) return rslt;

        // await util.wait(2000);

        let stockPrice = await appDriver.findElement({
          selector: { actionablId: "actionabl_2_1_1_2_2_1_1_1_1_1_1_1_23" },
          refresh: true,
        });

        if (stockPrice.rc != 0) return stockPrice;
        console.log(stockPrice.data.name);

        await util.wait(2000);
      }

      // Wait for some time or perform other actions on the website

      rslt = await appDriver.closeWindow();
      if (rslt.rc != 0) return rslt;
      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      self.$.test_review_complete = false;
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}

module.exports = customRPA;
