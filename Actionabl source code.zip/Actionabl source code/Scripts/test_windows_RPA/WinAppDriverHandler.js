const modules = global.modules;
const { util, winAppDriver } = modules;
const { WinAppDriver } = winAppDriver;

class WinAppDriverHandler {
    appDriver;
    appDriverOptions;
    appDriverConnected = false;

    constructor(appDriverOptions) {
        this.appDriverOptions = appDriverOptions;
        this.appDriver = new WinAppDriver();
    }

    async Connect() {
        if (!this.appDriver) {
            this.appDriver = new WinAppDriver();
        }

        let rslt = await this.appDriver.connect(this.appDriverOptions);

        this.appDriverConnected = (rslt.rc == 0);

        return rslt;
    }

    async ExecuteCommand(command, commandParams, attempt = 1) {
        let rslt;

        try {
            if (!this.appDriverConnected) {
                rslt = this.Connect();
                if (rslt.rc != 0) return rslt;
            }

            rslt = await this.appDriver[command](commandParams);
            if (rslt.rc != 0 && rslt.msg.indexOf('Failed to ElementFromHandle in getElementTree 0x80040201') > -1) {
                if (attempt > 3) return rslt;

                rslt = this.Connect();
                if (rslt.rc != 0) return rslt;

                return await this.ExecuteCommand(command, commandParams, attempt + 1);
            }
            else {
                return rslt;
            }

        }
        catch (e) {
            console.log(e);
            return { rc: 1, msg: `Error At WinAppDriverHandler.ExecuteCommmand: ${e.message}` };
        }
    }

    async FindElement(selector, maxAttempt = 30) {
        try {
            let rslt;
            let elementFound = false;

            let currnetAttempt = 1;

            if (!this.appDriverConnected) {
                rslt = this.Connect();
                if (rslt.rc != 0) return rslt;
            }
            while (!elementFound && currnetAttempt <= maxAttempt) {

                //Find Error message element
                rslt = await this.appDriver.findElement({ selector: selector, refresh: true });
                if (rslt.rc != 0) {
                    currnetAttempt++;
                    await util.wait(1000);
                }
                if (rslt.rc == 0) {
                    elementFound = true;
                }
            }

            return rslt;
        }
        catch (e) {
            return { rc: 1, msg: `error at WinAppDriverHandler.FindElement: ${e.message}` };
        }
    }
}


module.exports = WinAppDriverHandler;