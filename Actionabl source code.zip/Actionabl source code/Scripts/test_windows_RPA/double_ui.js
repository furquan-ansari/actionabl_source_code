const { util } = global.modules;
const modules = global.modules;
const { CustomRPABase, winAppDriver } = modules;
const { WinAppDriver, keyCode } = winAppDriver;

const WinAppDriverHandler = require("../test_windows_RPA/WinAppDriverHandler.js");

class customRPA extends CustomRPABase {
  async process() {
    let self = this;

    let rslt;
    try {
      let appDriver = new WinAppDriverHandler({
        executablePath: "C:\\Users\\LENOVO\\Downloads\\DoubleUI.exe",
        wait: 2000,
      });
      rslt = await appDriver.Connect();
      if (rslt.rc != 0) return rslt;


      rslt = await appDriver.ExecuteCommand("select", {
        selector: {
          controlType: "RadioButton",
          name: "Withdrawal",
          automationId: "Withdrawalradiobutton",
          class: "RadioButton",
        },
        refresh: true,
        addtionalAtElement: true,
      });

      rslt = await appDriver.ExecuteCommand("setValue", {
        selector: { controlType: "Edit", automationId: "check1" },
        value: 15,
        refresh: true,
      });

      rslt = await appDriver.ExecuteCommand("setValue", {
        selector: { controlType: "Edit", automationId: "check2" },
        value: 10,
        refresh: true,
      });

      rslt = await appDriver.ExecuteCommand("invoke", {
        selector: { name: "Accept", controlType: "Button", class: "Button" },
        refresh: true,
      });

      if (rslt.rc != 0) return rslt;
      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      self.$.test_review_complete = false;
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}

module.exports = customRPA;

/////////////////////////////////////////////////////////////////////////////

// const modules = global.modules;
// const { CustomRPABase, winAppDriver, util } = modules;
// const { WinAppDriver, keyCode } = winAppDriver;
// const WinAppDriverHandler = require('../test_windows_RPA/WinAppDriverHandler');

// class customRPA extends CustomRPABase {
//   async process() {
//     // Below code to fetch data from file
//     let self = this;
//     let params = self.$;
//     let rslt;

//     try {
//       let appDriver = new WinAppDriverHandler({title:"DoubleUI",wait:6000});
//       rslt = await appDriver.Connect();
//       if (rslt.rc != 0) return rslt;
//       await util.wait(2000);

//       rslt = await appDriver.ExecuteCommand('setValue', { selector: {automationId:'cashintb', controlType:'Edit', class:'TextBox'},value:90, refresh: true });

//          if (rslt.rc != 0) return rslt
//           await util.wait(2000)

//       rslt = await appDriver.ExecuteCommand('setValue', { selector: {automationId:'onustb', controlType:'Edit', class:'TextBox'},value:100, refresh: true });

//       rslt = await appDriver.ExecuteCommand('invoke', { selector: {name:'Accept', controlType:'Button', class:'Button'},value:100, refresh: true });

//     rslt = await appDriver.ExecuteCommand('select', { selector: {
//           controlType: "RadioButton", name: "Withdrawal", automationId: "Withdrawalradiobutton",class:"RadioButton", }, refresh: true, addtionalAtElement: true })

//       rslt = await appDriver.ExecuteCommand('setValue', { selector:{ automationId: "check1", controlType: "Edit", class: "TextBox", },value:100, refresh: true });

//       rslt = await appDriver.ExecuteCommand('setValue', { selector:{ automationId: "check2", controlType: "Edit", class: "TextBox", },value:100, refresh: true });

//       rslt = await appDriver.ExecuteCommand('invoke', { selector: {name:'Accept', controlType:'Button', class:'Button'},value:100, refresh: true });
// ;
//     rslt = await appDriver.ExecuteCommand('select', { selector:  {name: "Split Deposit",controlType: "RadioButton",class: "RadioButton",}, refresh: true, addtionalAtElement: true })

//     rslt = await appDriver.ExecuteCommand('setValue', { selector:{ automationId: "cashintb",controlType: "Edit", class: "TextBox", },value:100, refresh: true });

// //       rslt = await appDriver.setValue({
// //         selector: {
// //           automationId: "cashintb",
// //           controlType: "Edit",
// //           class: "TextBox",
// //         },
// //         value: 30,
// //         refresh: true,
// //       });
// //       if (rslt.rc != 0) return rslt;
// //       await util.wait(5000);

// //       rslt = await appDriver.setValue({
// //         selector: {
// //           automationId: "onustb",
// //           controlType: "Edit",
// //           class: "TextBox",
// //         },
// //         value: 40,
// //         refresh: true,
// //       });
// //       if (rslt.rc != 0) return rslt;
// //       await util.wait(5000);

// //       rslt = await appDriver.invoke({
// //         selector:{name:'Accept', controlType:'Button', class:'Button'},
// //         refresh: true,
// //       });
// //       if (rslt.rc != 0) return rslt;
//     //    rslt= await appDriver.closeWindow()
//        if (rslt.rc != 0) return rslt;
//       util.wait(2000);
//       return{rc:0}
//     } catch (error) {
//       console.log(error.message);
//       return { rc: 1, msg: error.message };
//     }
//   }
// }

// module.exports = customRPA;
