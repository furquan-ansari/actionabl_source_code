/* const { util } = global.modules;
const modules = global.modules;
const { CustomRPABase, winAppDriver, Excel } = modules;
const { WinAppDriver, keyCode } = winAppDriver;

class customRPA extends CustomRPABase {
  async process() {
    let self = this;
    let params = self.$;
    let rslt;

    try {
      let appDriver = new WinAppDriver();

      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\LENOVO\\Downloads\\Circulars_05-04-2024.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("NSDL");
      if (rslt.rc != 0) return rslt;

      let pdfLink = await excelBot.readRange("D2:D5");

      console.log(pdfLink.data);

      rslt = await appDriver.connect({
        executablePath:
          "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
      });
      if (rslt.rc != 0) return rslt;
      await util.wait(3000);

      rslt = await appDriver.setValue({
        selector: { automationId: "view_1022", name: "Address and search bar" },
        value: pdfLink.data[0],
        refresh: true,
      });
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      rslt = await appDriver.sendKey({
        hwnd: appDriver.handle,
        key: keyCode.VK_RETURN,
      });
      if (rslt.rc != 0) return rslt;

      await util.wait(2000);

      rslt = await appDriver.invoke({
        selector: { automationId: "save", name: "Save (Ctrl+S)" },
        refresh: true,
      });
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      rslt = await appDriver.invoke({
        selector: { automationId: "1", name: "Save" },
        refresh: true,
      });
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      //   rslt = await appDriver.closeWindow();
      if (rslt.rc != 0) return rslt;
      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      self.$.test_review_complete = false;
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}

module.exports = customRPA; */

///////////////////////////////////////////////////////////////////////////

// working code dynamic

const { util } = global.modules;
const modules = global.modules;
const { CustomRPABase, winAppDriver, Excel } = modules;
const { WinAppDriver, keyCode } = winAppDriver;

class customRPA extends CustomRPABase {
  async process() {
    let self = this;
    let params = self.$;
    let rslt;

    try {
      let appDriver = new WinAppDriver();

      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\LENOVO\\Downloads\\Circulars_05-04-2024.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("NSDL");
      if (rslt.rc != 0) return rslt;

      let pdfLink = await excelBot.readRange("D2:D5");

      console.log(pdfLink.data);

      rslt = await appDriver.connect({
        executablePath:
          "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
      });
      if (rslt.rc != 0) return rslt;
      await util.wait(3000);

      for (let i = 0; i < pdfLink.data.length; i++) {
        rslt = await appDriver.setValue({
          selector: {
            automationId: "view_1022",
            name: "Address and search bar",
          },
          value: pdfLink.data[i],
          refresh: true,
        });
        if (rslt.rc != 0) return rslt;
        await util.wait(2000);

        rslt = await appDriver.sendKey({
          hwnd: appDriver.handle,
          key: keyCode.VK_RETURN,
        });
        if (rslt.rc != 0) return rslt;

        await util.wait(2000);

        rslt = await appDriver.invoke({
          selector: { automationId: "save", name: "Save (Ctrl+S)" },
          refresh: true,
        });
        if (rslt.rc != 0) return rslt;
        await util.wait(2000);

        rslt = await appDriver.invoke({
          selector: { automationId: "1", name: "Save" },
          refresh: true,
        });
        if (rslt.rc != 0) return rslt;
        await util.wait(2000);
      }

      //   rslt = await appDriver.closeWindow();
      if (rslt.rc != 0) return rslt;
      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      self.$.test_review_complete = false;
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}

module.exports = customRPA;
