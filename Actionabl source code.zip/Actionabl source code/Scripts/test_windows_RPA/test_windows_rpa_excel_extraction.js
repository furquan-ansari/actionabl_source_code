const { util } = global.modules;
const modules = global.modules;
const { CustomRPABase, winAppDriver, Excel } = modules;
const { WinAppDriver, keyCode } = winAppDriver;

class customRPA extends CustomRPABase {
  async process() {
    let self = this;
    let params = self.$;
    let rslt;

    try {
      //write code here

      for(let row=2; row<=4; row++ ){
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      let appDriver = new WinAppDriver();

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\actionabl_testing_files\\excel_extraction.xlsx"
      );
      if (rslt.rc != 0) return rslt;

    //   let readCell = await excelBot.readCell("A2");
    let readCell = await excelBot.readCell(`A${row}`);
      if (rslt.rc != 0) return rslt;

    //   let readCell1 = await excelBot.readCell("B2");
    let readCell1 = await excelBot.readCell(`B${row}`);
      if (rslt.rc != 0) return rslt;

      await util.wait(2000);

      rslt = await appDriver.connect({
        executablePath: "C:\\Users\\LENOVO\\Downloads\\DoubleUI.exe",
      });
      if (rslt.rc != 0) return rslt;

      await util.wait(2000);

      rslt = await appDriver.select({
        selector: {
          controlType: "RadioButton",
          name: "Withdrawal",
          automationId: "Withdrawalradiobutton",
          class: "RadioButton",
        },
      });
      if (rslt.rc != 0) return rslt;



      rslt = await appDriver.setValue({
        selector: { controlType: "Edit", automationId: "check1" },
        value: readCell.data,
        refresh: true,
      });
      if (rslt.rc != 0) return rslt;

      rslt = await appDriver.setValue({
        selector: { controlType: "Edit", automationId: "check2" },
        value: readCell1.data,
        refresh: true,
      });
      if (rslt.rc != 0) return rslt;

      rslt = await appDriver.sendKey({ hwnd: appDriver.handle, key : keyCode.VK_TAB });
      if (rslt.rc != 0) return rslt;


      await util.wait(2000);

      appDriver = new WinAppDriver();
      rslt = await appDriver.connect({
        executablePath: "C:\\Users\\LENOVO\\Downloads\\DoubleUI.exe",
      });
      if (rslt.rc != 0) return rslt;



      let totalVal = await appDriver.findElement({
        selector: {automationId:'TotalLB2'},
        refresh: true,
      });
      if (totalVal.rc != 0) return totalVal;
      console.log(totalVal.data.name);

      await util.wait(2000);

    //   rslt = await excelBot.fill("C2", totalVal.data.name);
    rslt = await excelBot.fill(`C${row}`, totalVal.data.name);
      if (rslt.rc != 0) return rslt;

      rslt = await appDriver.invoke({
        selector: { name: "Accept", controlType: "Button" },
        refresh: true,
      });
      if (rslt.rc != 0) return rslt;

      await util.wait(2000);
    }
    self.$.test_review_complete = true;
    rslt = await appDriver.closeWindow();
    if (rslt.rc != 0) return rslt;
    return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      self.$.test_review_complete = false;
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}

module.exports = customRPA;
