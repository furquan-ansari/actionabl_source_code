const { util } = global.modules;
const modules = global.modules;
const { CustomRPABase, winAppDriver } = modules;
const { WinAppDriver, keyCode } = winAppDriver;

class customRPA extends CustomRPABase {
    async process() {
        let self = this;
        let params = self.$;
        let rslt;
        try {

            //write code here
            let appDriver = new WinAppDriver();
            //  rslt = await appDriver.connect({ title: user });
            //  if (rslt.rc == 0) return rslt;

            rslt = await appDriver.connect({ executablePath: 'C:\\Users\\LENOVO\\Downloads\\DoubleUI.exe'});
            if (rslt.rc != 0) return rslt;

            await util.wait(10000);

            // rslt = await appDriver.connect({ executablePath: appPath });
            // if (rslt.rc != 0) return rslt;
            rslt = await appDriver.select({ selector: {  controlType: "RadioButton", name: "Split Deposit",class: "RadioButton"} });
            if (rslt.rc != 0) return rslt;

               rslt = await appDriver.setValue({ selector: { controlType: "Edit",
               automationId: "cashintb",}, value: 10, refresh: true });
               if (rslt.rc != 0) return rslt;

             rslt = await appDriver.setValue({ selector: {controlType: "Edit",
             automationId: "onustb"} , value: 20, refresh: true});
             if (rslt.rc != 0) return rslt;

             rslt = await appDriver.setValue({ selector: {controlType: "Edit",
             automationId: "notonustb"} , value: 30, refresh: true});
             if (rslt.rc != 0) return rslt;

             await util.wait(2000);
             rslt = await appDriver.invoke({ selector:{name:'Accept', controlType:'Button'}, refresh: true });
             if (rslt.rc != 0) return rslt;
            self.$.test_review_complete = true;
            rslt = await appDriver.closeWindow();
            if (rslt.rc != 0) return rslt;
            return { rc: 0 };


        }
        catch (e) {
            console.log(`Exception: ${e.message}`);
            self.$.test_review_complete = false;
            return { rc: 1, msg: `Exception: ${e.message}` };
        }
    }
}

module.exports = customRPA;
