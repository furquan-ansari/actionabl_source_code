let modules = global.modules;
let { CustomRPABase, Excel } = modules;
// const format = modules.require("date-fns/format");

class customRPA extends CustomRPABase {
  async process() {
    // Below code to create excel file
/*     let excelBot = new Excel.bot();
    let rslt = await excelBot.init({ visible: true });
    rslt = await excelBot.create();
    if (rslt.rc != 0) return rslt;
    let result = rslt.data;
    console.log(result);
    return { rc: 0 }; */

    //   Below code to add file
       /*  let excelBot = new Excel.bot();
    let rslt = await excelBot.init({ visible: true });
    rslt = await excelBot.add('C:\\Users\\Furquan\\actionabl_testing_files\\Book1.xlsx');
    if (rslt.rc != 0) return rslt;
    let result = rslt.data;
      console.log(result);
    return { rc: 0 }; */

    // Below code to open file
    /*     let excelBot = new Excel.bot();
    let rslt = await excelBot.init({ visible: true });
    rslt = await excelBot.open('C:\\Users\\Furquan\\actionabl_testing_files\\Book1.xlsx');
    if (rslt.rc != 0) return rslt;
    let result = rslt.data;
    console.log(result);
    return { rc: 0 };
  */

    // Below code to fill cell
    /*     let excelBot = new Excel.bot();
    let rslt = await excelBot.init({ visible: true });
    rslt = await excelBot.open('C:\\Users\\Furquan\\actionabl_testing_files\\Book1.xlsx');
    rslt = await excelBot.fill('A2', 'Furquan');
    if (rslt.rc != 0) return rslt;
    let result = rslt.data;
    console.log(result);
    return { rc: 0 }; */

    // Below code to fill range
/*     let excelBot = new Excel.bot();
    let rslt = await excelBot.init({ visible: true });
    rslt = await excelBot.open('C:\\Users\\Furquan\\actionabl_testing_files\\Book1.xlsx');
    rslt = await excelBot.fillRange('A3:A4', 'Rakesh');
    if (rslt.rc != 0) return rslt;
    let result = rslt.data;
    console.log(result);
    return { rc: 0 };  */

    // Below code to read cell
/*     let excelBot = new Excel.bot();
    let rslt = await excelBot.init({ visible: true });
    rslt = await excelBot.open("C:\\Users\\Furquan\\actionabl_testing_files\\Book1.xlsx");
    rslt = await excelBot.readCell('A2');
    if (rslt.rc != 0) return rslt;
    let result = rslt.data;
    console.log(result);
    return { rc: 0 }; */

    // Below code to add worksheet
/*     let excelBot = new Excel.bot();
    let rslt = await excelBot.init({ visible: true });
    rslt = await excelBot.open("C:\\Users\\Furquan\\actionabl_testing_files\\Book1.xlsx");
    rslt = await excelBot.addWorksheet();
    if (rslt.rc != 0) return rslt;
    let result = rslt.data;
    console.log(result);
    return { rc: 0 }; */

  }

}
module.exports = customRPA;
