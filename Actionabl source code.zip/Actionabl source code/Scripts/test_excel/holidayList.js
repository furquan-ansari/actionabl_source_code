/* let modules = global.modules;
let { CustomRPABase, Excel } = modules;
// const format = modules.require("date-fns/format");

class customRPA extends CustomRPABase {
  async process() {

    try{

    // let excelBot = new Excel.bot();
    // let rslt = await excelBot.init({ visible: true });
    // rslt = await excelBot.open("C:\\Users\\Furquan\\actionabl_testing_files\\holiday_list_2024.xlsx");

    // rslt =  await excelBot.switchToSheetByNumber(3);
    // rslt = await excelBot.readRange('A1:A20');

    // let result = rslt.data;
    // console.log(result);

    function getPreviousSaturday() {
      const currentDate = new Date();
      const dayOfWeek = currentDate.getDay();

      // Holiday list
      const holidayList = [ "Tue Feb 13 2024","Wed Feb 14 2024","Thur Feb 15 2024",
        "Mon Jan 22 2024", "Fri Jan 26 2024", "Fri Mar 08 2024", "Mon Mar 25 2024", "Fri Mar 29 2024", "Thur Apr 11 2024",
        "Sun Apr 14 2024", "Wed Apr 17 2024", "Sun Apr 21 2024", "Wed May 01 2024", "Mon Jun 17 2024", "Wed July 17 2024",
        "Thur Aug 15 2024", "Sat Sept 07 2024", "Wed Oct 02 2024", "Sat Oct 12 2024", "Fri Nov 01 2024", "Sat Nov 02 2024",
        "Fri Nov 15 2024", "Wed Dec 25 2024"
      ];

      // Check if a holiday is just before the current date
      const isHolidayBeforeCurrentDate = holidayList.some(holiday => {
        const holidayDate = new Date(holiday);
        const diffInDays = Math.floor((currentDate - holidayDate) / (1000 * 60 * 60 * 24));
        return diffInDays === 1;
      });

      if (isHolidayBeforeCurrentDate) {
        currentDate.setDate(currentDate.getDate() - 1);
      }

      // Rest of the logic
      if (dayOfWeek !== 1 && dayOfWeek !== 0) {
        currentDate.setDate(currentDate.getDate() - 1);
      }

      if (dayOfWeek === 1) {
        const previousSaturday = new Date(currentDate);
        previousSaturday.setDate(currentDate.getDate() - 1);

        const month = previousSaturday.getMonth();
        const dayOfMonth = previousSaturday.getDate();

        const isSecondFourthSaturday = (dayOfMonth >= 8 && dayOfMonth <= 14 && previousSaturday.getDay() === 6) ||
          (dayOfMonth >= 22 && dayOfMonth <= 28 && previousSaturday.getDay() === 6);

        if (isSecondFourthSaturday) {
          const daysToSubtract = (dayOfWeek === 1) ? 3 : 1;
          previousSaturday.setDate(previousSaturday.getDate() - daysToSubtract);
          console.log(previousSaturday.toDateString());
          return;
        } else {
          const isFirstThirdFifthSaturday = (dayOfMonth <= 7 && previousSaturday.getDay() === 6) ||
            (dayOfMonth >= 15 && dayOfMonth <= 21 && previousSaturday.getDay() === 6) ||
            (dayOfMonth >= 29 && dayOfMonth <= 31 && previousSaturday.getDay() === 6);

          if (isFirstThirdFifthSaturday) {
            console.log(previousSaturday.toDateString());
            return;
          } else {
            previousSaturday.setDate(previousSaturday.getDate() - 1);
            console.log(previousSaturday.toDateString());
            return;
          }
        }
      }

      if (dayOfWeek === 0) {
        const previousDate = new Date(currentDate);
        previousDate.setDate(currentDate.getDate() - 1);

        const month = previousDate.getMonth();
        const dayOfMonth = previousDate.getDate();

        const isFirstThirdFifthSaturday = (dayOfMonth <= 7 && previousDate.getDay() === 6) ||
          (dayOfMonth >= 15 && dayOfMonth <= 21 && previousDate.getDay() === 6) ||
          (dayOfMonth >= 29 && dayOfMonth <= 31 && previousDate.getDay() === 6);

        if (isFirstThirdFifthSaturday) {
          console.log(previousDate.toDateString());
          return;
        } else {
          previousDate.setDate(previousDate.getDate() - 1);
          console.log(previousDate.toDateString());
          return;
        }
      }

      console.log(currentDate.toDateString());
    }

    getPreviousSaturday();
    }

    catch(e){
        console.log(e);
    }
    return { rc: 0 };

  }

}
module.exports = customRPA; */


///////////////////////////////////////////////////////////////////////////

// Not working for back to back holiday
/* 
const modules = global.modules;
const { bfs, CustomRPABase } = modules;
const path = require('path');
const {format} = modules.require('date-fns/format');

class customRPA extends CustomRPABase {
  async process() {
    let self = this;
    let params = self.$;
    let rslt;

    try {
      const currentDate = new Date();
      let previousDate = new Date(currentDate);
      previousDate.setDate(currentDate.getDate() - 1);
      
    const holidayList = ['05-Mar-2024','06-Mar-2024','07-Mar-2024', '30-Mar-2024', '04-Apr-2024', '07-Apr-2024', '14-Apr-2024', '01-May-2024', '29-Jun-2024', '15-Aug-2024', '19-Sep-2024', '02-Oct-2024', '24-Oct-2024', '14-Nov-2024', '27-Nov-2024', '25-Dec-2024'];
    function isSunday(date) {
      return date.getDay() === 0; // Sunday is represented by 0 in JavaScript's Date object
    }
    function isHoliday(date) {
      // Check if the date is in the holidayList array
      let con=false;
      let val=0;
      const formattedDate = `${date.getDate()}-${date.toLocaleString('default', { month: 'short' })}-${date.getFullYear()}`;
      for(let i=0;i<holidayList.length;i++){
      if( holidayList[i].includes(formattedDate)){
        val+=1;
        con=true;
       
      }
      return {con,val};
    }
    }
    // 2nd and 4th week
    function isSecondOrFourthWeek(date) {
      const weekOfMonth = Math.ceil(date.getDate() / 7);
      return weekOfMonth === 2 || weekOfMonth === 4;
    }
    
  
    if (isSunday(previousDate)) {
      // Return Saturday date
      previousDate.setDate(previousDate.getDate() - 1);
    } else if (isHoliday(previousDate).con || isSecondOrFourthWeek(previousDate)) {
      // Move to the previous Friday
      console.log(isHoliday(previousDate).val);
      do {
        previousDate.setDate(previousDate.getDate() - isHoliday(previousDate).val);
      } while (previousDate.getDay() !== 5); // 5 represents Friday
    }
    console.log(previousDate);
    let formattedDate = format(previousDate, 'dd-MM-yyyy');
 
      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
  
}

module.exports = customRPA; */

//////////////////////////////////////////////////////////

