const modules = global.modules;
const { bfs, CustomRPABase, Excel } = modules;
const { format } = modules.require("date-fns/format");
class customRPA extends CustomRPABase {
  async process() {
    let self = this;
    let params = self.$;
    let rslt;
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;
      let path =
        "C:\\Users\\Furquan\\actionabl_testing_files\\ExcelTaskCopy.xlsx";
      //   rslt = await excelBot.create(path);
      //   if (rslt.rc != 0) return rslt
      // rslt = await excelBot.saveWorkbook(path);
      // if (rslt.rc != 0) return rslt;
      rslt = await excelBot.open(path);
      if (rslt.rc != 0) return rslt;
      rslt = await excelBot.readRange("C2:C56");
      if (rslt.rc != 0) return rslt;
      let empName = rslt.data;
      rslt = await excelBot.readRange("E2:E56");
      if (rslt.rc != 0) return rslt;
      let deptCode = rslt.data;
      let employeeData = {};
      for (let i = 0; i < empName.length; i++) {
        let employeeName = empName[i];
        let departmentCode = deptCode[i];
        employeeData[employeeName] = departmentCode;
      }
      //  console.log(employeeData);
      rslt = await excelBot.switchToSheet("Employee Master");
      //if (rslt.rc != 0) return rslt;
      rslt = await excelBot.readRange("B2:B56");
      if (rslt.rc != 0) return rslt;
      let secondSheetName = rslt.data;
      //   for(let i=0;i<secondSheetName.length;i++){
      //     let label = secondSheetName[i];
      //     let val=employeeData[label[0]];
      //     let name=employeeData.label;
      //     if(label==name)
      //          rslt = await excelBot.fill(`D${i+2}`,val);
      //          if (rslt.rc != 0) return rslt;
      //  }
      for (let i = 0; i < secondSheetName.length; i++) {
        let secondSheetEmpName = secondSheetName[i];
        if (employeeData.hasOwnProperty(secondSheetEmpName)) {
          let departmentCode = employeeData[secondSheetEmpName];
          rslt = await excelBot.fill(`D${i + 2}`, departmentCode); // Assuming department code goes in column D
          if (rslt.rc !== 0) return rslt;
        }
      }
      rslt = await excelBot.readRange("A2:A56");
      if (rslt.rc != 0) return rslt;
      let digits = rslt.data;
      for (let i = 0; i < digits.length; i++) {
        let num = digits[i][0];
        let digit = digits[i][0].length;
        if (digit != 7) {
          let nums = 7 - digit;
          3;
          let newDigit = num.padStart(digit + nums, "0");
          // console.log(newDigit);
          rslt = await excelBot.fill(`A${i + 2}`, newDigit);
          if (rslt.rc !== 0) return rslt;
        }
      }
      rslt = await excelBot.readRange("E2:E56");
      if (rslt.rc != 0) return rslt;
      let dates = rslt.data;
      rslt = await excelBot.readRange("F2:F56");
      if (rslt.rc != 0) return rslt;
      let enDate = rslt.data;
      for (let i = 0; i < enDate.length; i++) {
        let date = enDate[i][0];
        if (!date) {
          let currDate = new Date();
          let formattedDate = format(currDate, "MM-dd-yyyy");
          rslt = await excelBot.fill(`F${i + 2}`, formattedDate);
          if (rslt.rc !== 0) return rslt;
        }
      }
      rslt = await excelBot.readRange("F2:F56");
      if (rslt.rc != 0) return rslt;
      let enDate1 = rslt.data;
      function convertDateToMonthsOrYears(givenDate, enddate) {
        if (!givenDate) {
          givenDate = new Date(); // Use the current date if givenDate is undefined
        } else if (!(givenDate instanceof Date)) {
          let datePartsSlash = givenDate.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
          if (datePartsSlash) {
            givenDate = new Date(
              `${datePartsSlash[3]}-${datePartsSlash[2]}-${datePartsSlash[1]}`
            );
          } else {
            givenDate = new Date(givenDate);
          }
        }
        if (!enddate) {
          enddate = new Date(); // Use the current date if givenDate is undefined
        } else if (!(enddate instanceof Date)) {
          let datePartsSlash = enddate.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
          if (datePartsSlash) {
            enddate = new Date(
              `${datePartsSlash[3]}-${datePartsSlash[2]}-${datePartsSlash[1]}`
            );
          } else {
            enddate = new Date(enddate);
          }
        }
        // let currentDate = new Date();
        let yearsDifference = enddate.getFullYear() - givenDate.getFullYear();
        let givenMonth = givenDate.getMonth();
        let endMonth = enddate.getMonth();
        let remainingMonths = 0;

        if (endMonth < givenMonth) {
          yearsDifference--;
          remainingMonths = 12 + endMonth - givenMonth;
        } else {
          remainingMonths = endMonth - givenMonth;
        }

        return `${yearsDifference}Y.${remainingMonths}M`;
      }

      for (let i = 0; i < dates.length; i++) {
        let givenDate = dates[i][0];
        let enddate = enDate1[i][0];
        let result = convertDateToMonthsOrYears(givenDate, enddate);
        //result = parseFloat(result).toFixed(2);
        rslt = await excelBot.fill(`G${i + 2}`, result);
        if (rslt.rc !== 0) return rslt;
      }
      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}
module.exports = customRPA;
