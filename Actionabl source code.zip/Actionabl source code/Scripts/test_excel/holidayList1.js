/* 
let modules = global.modules;
let { CustomRPABase, Excel } = modules;
const dateFns = modules.require('date-fns');
const format = modules.require('date-fns/format');
const {addDays} = modules.require('date-fns/addDays');

class customRPA extends CustomRPABase {
    async process() {

        try {

            const currentDate = new Date();
            //   const dayOfWeek = currentDate.getDay();

            // Holiday list
            const holidayData = [
                "Mon Jan 22 2024", "Fri Jan 26 2024","Sat Feb 03 2024", "Tue Feb 13 2024", "Wed Feb 14 2024", "Thu Feb 15 2024", "Mon Mar 25 2024", "Fri Mar 29 2024", "Thur Apr 11 2024",
                "Sun Apr 14 2024", "Wed Apr 17 2024", "Sun Apr 21 2024", "Wed May 01 2024", "Mon Jun 17 2024", "Wed July 17 2024",
                "Thur Aug 15 2024", "Sat Sept 07 2024", "Wed Oct 02 2024", "Sat Oct 12 2024", "Fri Nov 01 2024", "Sat Nov 02 2024",
                "Fri Nov 15 2024", "Wed Dec 25 2024"
            ];

            let currday = addDays(new Date(), -1);
            currday.setHours(0);
            currday.setMinutes(0);
            currday.setSeconds(0);

            if (holidayData.includes(currday.toDateString())) {
                currday = addDays(currday, -1);
            }

            let week = currday.getDay();
            if (week == 0) {
                let weekOfMonth = Math.floor((currday.getDate() - 1) / 7) + 1;
                if (weekOfMonth === 1 || weekOfMonth === 3 || weekOfMonth === 5) {
                    let Isholiday = false;
                    switch (currday.getDay()) {
                        case 0:
                            currday = addDays(currday, -1);
                            Isholiday = holidayData.includes(currday.toDateString());
                            while (Isholiday) {
                                currday = addDays(currday, -1);
                                Isholiday = holidayData.includes(currday.toDateString());
                            }
                            break;
                    }
                }
                else {
                    let Isholiday = false;
                    switch (currday.getDay()) {
                        case 0:
                            currday = addDays(currday, -2);
                            Isholiday = holidayData.includes(currday.toDateString());
                            while (Isholiday) {
                                currday = addDays(currday, -1);
                                Isholiday = holidayData.includes(currday.toDateString());
                            }
                            break;
                    }
                }


            }
            else {
                let Isholiday = false;
                switch (currday.getDay()) { case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                        //currday = addDays(currday, -1);
                         Isholiday = holidayData.includes(currday.toDateString());
                        while (Isholiday) {
                            currday = addDays(currday, -1);
                            Isholiday = holidayData.includes(currday.toDateString());
                        }
                        break;

                    default:
                }
            }

            console.log(currday.toDateString());
            return { rc: 0 };
        }

        catch (e) {
            console.log(e);
        }

    }
}

module.exports = customRPA; */

//////////////////////////////////////////////////////////

// Another logic using recursion logic

let modules = global.modules;
let { CustomRPABase, Excel } = modules;


class customRPA extends CustomRPABase {
    async process() {

        try {

            const date = new Date();
            const year = date.getFullYear();
            const monthName = date.toLocaleDateString('en-US', { month: 'short' });
            const DAYS_IN_MONTH = 31;


            function calculateNthSaturday(month, year, n) {
              const firstDayOfMonth = new Date(`${month} 1, ${year}`);
              let count = 0;

              for (let day = 1; day <= DAYS_IN_MONTH; day++) {
                const currentDay = new Date(`${month} ${day}, ${year}`);
                if (currentDay.getDay() === 6) {
                  count++;
                  if (count === n) {
                    return currentDay;
                  }
                }
              }

              return null; // Return null if the nth Saturday is not found
            }

            function formatDate(date) {
              const months = [
                "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
              ];

              return `${date.getDate()}-${months[date.getMonth()]}-${date.getFullYear()}`;
            }

            function calculate2ndAnd4thSaturday(month, year) {
              const secondSaturday = calculateNthSaturday(month, year, 2);
              const fourthSaturday = calculateNthSaturday(month, year, 4);

              return [formatDate(secondSaturday), formatDate(fourthSaturday)];
            }
            const [secondSaturday, fourthSaturday] = calculate2ndAnd4thSaturday(monthName, year);


            function goBackDays(dateString, days) {
              const months = [
                "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
              ];
              // Parse the date string into a Date object
              const date = new Date(dateString);
              // Subtract the specified number of days
              date.setDate(date.getDate() - days);
              // Format the resulting date
              const formattedDate = `${date.getDate()}-${months[date.getMonth()]}-${date.getFullYear()}`;

              return formattedDate;
            }


            const holidayList = [
              "22-Jan-2024", "26-Jan-2024","3-Feb-2024", "7-Feb-2024",
              "8-Feb-2024", "23-Feb-2024", "8-Mar-2024", "25-Mar-2024", "29-Mar-2024",
              "11-Apr-2024", "14-Apr-2024", "17-Apr-2024", "21-Apr-2024", "1-May-2024",
              "17-Jun-2024", "17-Jul-2024", "15-Aug-2024", "7-Sep-2024", "2-Oct-2024",
              "12-Oct-2024", "1-Nov-2024", "2-Nov-2024", "15-Nov-2024", "25-Dec-2024"
            ];

            function isTodayHoliday(today) {
              return holidayList.includes(today);
            }

            function isTodaySunday(today) {
              const currentDay = new Date(today);
              return currentDay.getDay() === 0; // Sunday has index 0 in JavaScript
            }

            function isToday2ndOr4thSat(today) {
              return today === secondSaturday || today === fourthSaturday;
            }

            function recursionFunForEveryCondition(today, flag) {
              if (flag) {
                return today;
              }

              const prevDay = goBackDays(today, 1);
              if (isTodayHoliday(prevDay) || isTodaySunday(prevDay) || isToday2ndOr4thSat(prevDay)) {
                return recursionFunForEveryCondition(prevDay, false);
              } else {
                return recursionFunForEveryCondition(prevDay, true);
              }
            }

            const currentDate = date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }).replace(/ /g, "-");
            const result = recursionFunForEveryCondition(currentDate, false);

            console.log(result);

            return { rc: 0 };
        }

        catch (e) {
            console.log(e);
        }

    }
}

module.exports = customRPA;