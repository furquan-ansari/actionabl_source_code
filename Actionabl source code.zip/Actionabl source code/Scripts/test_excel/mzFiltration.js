/* let modules = global.modules;
let { CustomRPABase, Excel } = modules;
let XLSX = modules.require("xlsx");

class customRPA extends CustomRPABase {
  async process() {


    try {

// Function to filter and copy data
function filterAndCopy(filePath, sheetName, columnName, filterValues) {
  // Read the Excel file
  const workbook = XLSX.readFile(filePath);
  const sheet = workbook.Sheets[sheetName];

  // Get column range
  const range = XLSX.utils.decode_range(sheet['!ref']);
  const colIndex = XLSX.utils.decode_col(columnName);

  // Array to store matching rows
  const matchingRows = [];

  // Iterate through rows
  for (let rowIndex = range.s.r + 1; rowIndex <= range.e.r; rowIndex++) {
    const cellAddress = { c: colIndex, r: rowIndex };
    const cellRef = XLSX.utils.encode_cell(cellAddress);
    const cellValue = sheet[cellRef] ? sheet[cellRef].v : '';

    // Check if the cell value is in the filterValues array
    if (filterValues.includes(cellValue)) {
      // Copy the entire row and add to the array
      const row = [];
      for (let col = range.s.c; col <= range.e.c; col++) {
        const cell = sheet[XLSX.utils.encode_cell({ c: col, r: rowIndex })];
        row.push(cell ? cell.v : '');
      }
      matchingRows.push(row);
    }
  }

  // Separate arrays for properties starting with specific characters
  const startsWithCTHS = matchingRows.filter(row => row[0].startsWith('CTHS'));
  const startsWithDPCTHS = matchingRows.filter(row => row[0].startsWith('DP_CTHS'));
  const startsWithEDIS = matchingRows.filter(row => row[0].startsWith('EDIS'));
  const startsWithHTHS = matchingRows.filter(row => row[0].startsWith('HTHS'));

  return {
    matchingRows,
    startsWithCTHS,
    startsWithDPCTHS,
    startsWithEDIS,
    startsWithHTHS
  };
}

// Function to write data to a new Excel file
function writeToExcel(data, fileName) {
  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  XLSX.writeFile(wb, fileName);
}

// Example usage with multiple filter values
const filePath = "C:/Users/Furquan/actionabl_testing_files/hrt_payin.xlsx";
const sheetName = 'Sheet1';
const columnName = 'C'; // Assuming the column is 'C'
const filterValues = ['M', 'Z']; // Array of filter values

const result = filterAndCopy(filePath, sheetName, columnName, filterValues);

// Write data to separate Excel files
writeToExcel(result.startsWithCTHS, 'C:/Users/Furquan/actionabl_testing_files/mzfiltration_excel_files/connector_excel_files/CTHS.xlsx');
writeToExcel(result.startsWithDPCTHS, 'C:/Users/Furquan/actionabl_testing_files/mzfiltration_excel_files/connector_excel_files/DP_CTHS.xlsx');
writeToExcel(result.startsWithEDIS, 'C:/Users/Furquan/actionabl_testing_files/mzfiltration_excel_files/connector_excel_files/EDIS.xlsx');
writeToExcel(result.startsWithHTHS, 'C:/Users/Furquan/actionabl_testing_files/mzfiltration_excel_files/connector_excel_files/HTHS.xlsx');



      // let excelBot = new Excel.bot();
      // let rslt = await excelBot.init({ visible: true });
      // rslt = await excelBot.open(
      //   "C:\\Users\\Furquan\\actionabl_testing_files\\hrt_payin.xlsx"
      // );



      // if (rslt.rc != 0) return rslt;
      // let result = rslt.data;
      // console.log(result);
      // return { rc: 0 };
    } catch (e) {
      console.log(e);
    }
    return { rc: 0 };
  }
}
module.exports = customRPA; */

/* ++++++++ Another approach but using same output excel file with different sheets +++++++++++++ */

/* let modules = global.modules;
let { CustomRPABase, Excel } = modules;
let XLSX = modules.require("xlsx");

class customRPA extends CustomRPABase {
  async process() {


    try {
// Function to filter and copy data
function filterAndCopy(filePath, sheetName, columnName, filterValues) {
  // Read the Excel file
  const workbook = XLSX.readFile(filePath);
  const sheet = workbook.Sheets[sheetName];

  // Get column range
  const range = XLSX.utils.decode_range(sheet['!ref']);
  const colIndex = XLSX.utils.decode_col(columnName);

  // Array to store matching rows
  const matchingRows = [];

  // Iterate through rows
  for (let rowIndex = range.s.r + 1; rowIndex <= range.e.r; rowIndex++) {
    const cellAddress = { c: colIndex, r: rowIndex };
    const cellRef = XLSX.utils.encode_cell(cellAddress);
    const cellValue = sheet[cellRef] ? sheet[cellRef].v : '';

    // Check if the cell value is in the filterValues array
    if (filterValues.includes(cellValue)) {
      // Copy the entire row and add to the array
      const row = [];
      for (let col = range.s.c; col <= range.e.c; col++) {
        const cell = sheet[XLSX.utils.encode_cell({ c: col, r: rowIndex })];
        row.push(cell ? cell.v : '');
      }
      matchingRows.push(row);
    }
  }

  // Separate arrays for properties starting with specific characters
  const startsWithCTHS = matchingRows.filter(row => row[0].startsWith('CTHS'));
  const startsWithDPCTHS = matchingRows.filter(row => row[0].startsWith('DP_CTHS'));
  const startsWithEDIS = matchingRows.filter(row => row[0].startsWith('EDIS'));
  const startsWithHTHS = matchingRows.filter(row => row[0].startsWith('HTHS'));

  return {
    matchingRows,
    startsWithCTHS,
    startsWithDPCTHS,
    startsWithEDIS,
    startsWithHTHS
  };
}

// Function to write data to a new Excel file
function writeToExcel(outputFilePath, sheets) {
  const newWorkbook = XLSX.utils.book_new();

  for (const sheetName in sheets) {
    if (sheets.hasOwnProperty(sheetName)) {
      const data = sheets[sheetName];
      const worksheet = XLSX.utils.aoa_to_sheet(data);
      XLSX.utils.book_append_sheet(newWorkbook, worksheet, sheetName);
    }
  }

  XLSX.writeFile(newWorkbook, outputFilePath);
}

// Example usage with multiple filter values
const filePath = "C:/Users/Furquan/actionabl_testing_files/hrt_payin.xlsx";
const sheetName = 'Sheet1';
const columnName = 'C'; // Assuming the column is 'A'
const filterValues = ['M', 'Z']; // Array of filter values

const result = filterAndCopy(filePath, sheetName, columnName, filterValues);

// Write to a new Excel file
const outputFilePath = "C:/Users/Furquan/actionabl_testing_files/mzfiltration_excel_files/connector_excel_files/output_hrt_payin.xlsx";
writeToExcel(outputFilePath, {
  'M_Z': result.matchingRows,
  'CTHS': result.startsWithCTHS,
  'DP_CTHS': result.startsWithDPCTHS,
  'EDIS': result.startsWithEDIS,
  'HTHS': result.startsWithHTHS,
});

console.log( outputFilePath);

      // let excelBot = new Excel.bot();
      // let rslt = await excelBot.init({ visible: true });
      // rslt = await excelBot.open(
      //   "C:\\Users\\Furquan\\actionabl_testing_files\\hrt_payin.xlsx"
      // );



      // if (rslt.rc != 0) return rslt;
      // let result = rslt.data;
      // console.log(result);
      // return { rc: 0 };
    } catch (e) {
      console.log(e);
    }
    return { rc: 0 };
  }
}
module.exports = customRPA;

 */

/* ++++++++++++++++++++++ Another approach without using xlsx module +++++++++++++++++++++++++++++ */

/* let modules = global.modules;
let { CustomRPABase, Excel } = modules;

class customRPA extends CustomRPABase {
  async process() {
    try {
      let excelBot = new Excel.bot();
      let rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;
      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\actionabl_testing_files\\hrt_payin.xlsx"
      );
      if (rslt.rc != 0) return rslt;

      let rowDataArray = [];

      for (let row = 6; row <= 128; row++) {
        rslt = await excelBot.readRange(`A${row}:H${row}`);
        let rowData = rslt.data[0];
        rowDataArray.push(rowData);
        // console.log(rowData);
      }
      // console.log(rowDataArray);

      // Filter rows containing 'M' or 'Z'
      let filteredRows = rowDataArray.filter(
        (rowData) => rowData.includes("M") || rowData.includes("Z")
      );
      // console.log(filteredRows);

      // Separate arrays based on filenames
      let CTHS_Data = filteredRows.filter((rowData) =>
        /^CTHS/i.test(rowData[0])
      );
      let DP_CTHS_Data = filteredRows.filter((rowData) =>
        /^DP_CTHS/i.test(rowData[0])
      );
      let EDIS_Data = filteredRows.filter((rowData) =>
        /^EDIS/i.test(rowData[0])
      );
      let HTHS_Data = filteredRows.filter((rowData) =>
        /^HTHS/i.test(rowData[0])
      );

      console.log(CTHS_Data);
      console.log(DP_CTHS_Data);
      console.log(EDIS_Data);
      console.log(HTHS_Data);

      let path =
        "C:\\Users\\Furquan\\actionabl_testing_files\\mzfiltration_excel_files\\connector_excel_files\\output1_hrt_payin.xlsx";
      rslt = await excelBot.create(path);
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.saveWorkbook(path);
      if (rslt.rc != 0) return rslt;

      //  rslt = await excelBot.addWorksheet();
      //  let sheet1 = workbook.getWorksheet("Sheet1");
      //  sheet1.setName("CTHS");

      let sheetsToCreate = ["CTHS", "DP_CTHS", "EDIS", "HTHS"];

      for (let sheetName of sheetsToCreate) {
        let sheetExists = false;

        for (let i = 1; i <= excelBot.workbook.worksheets.Count; i++) {
          if (excelBot.workbook.worksheets.Item(i).Name === sheetName) {
            sheetExists = true;
            break;
          }
        }

        if (!sheetExists) {
          let newWorkSheet = excelBot.workbook.worksheets.Add();
          newWorkSheet.Name = sheetName;
        }
      }
      // if (rslt.rc != 0) return rslt;

      //  rslt = await excelBot.switchToSheet('CTHS');
      // if (rslt.rc != 0) return rslt;
      // rslt = await excelBot.fill('A2', 'Furquan');

      //  rslt = await excelBot.fill('CTHS', CTHS_Data);
      //  rslt = await excelBot.fill('DP_CTHS', DP_CTHS_Data);
      //  rslt = await excelBot.fill('EDIS', EDIS_Data);
      //  rslt = await excelBot.fill('HTHS', HTHS_Data);

      // let dataToFill;
      // switch (sheetName) {
      //   case "CTHS":
      //     dataToFill = CTHS_Data;
      //     break;
      //   case "DP_CTHS":
      //     dataToFill = DP_CTHS_Data;
      //     break;
      //   case "EDIS":
      //     dataToFill = EDIS_Data;
      //     break;
      //   case "HTHS":
      //     dataToFill = HTHS_Data;
      //     break;
      // }
      //  rslt = await excelBot.saveWorkbook(path);
      // if (rslt.rc != 0) return rslt;

      await excelBot.switchToSheet("CTHS");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.fillRange("A1:H17", CTHS_Data);
      if (rslt.rc != 0) return rslt;

      await excelBot.switchToSheet("DP_CTHS");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.fillRange("A1:H12", DP_CTHS_Data);
      if (rslt.rc != 0) return rslt;

      await excelBot.switchToSheet("EDIS");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.fillRange("A1:H3", EDIS_Data);
      if (rslt.rc != 0) return rslt;

      await excelBot.switchToSheet("HTHS");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.fillRange("A1:H17", HTHS_Data);
      if (rslt.rc != 0) return rslt;

      // if (rslt.rc != 0) return rslt;

      rslt = await excelBot.saveWorkbook(path);
      if (rslt.rc != 0) return rslt;

      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}
module.exports = customRPA;
 */

///////////////////////////////////////////////////////////////////////

//  Clean code for above one
let modules = global.modules;
let { CustomRPABase, Excel } = modules;

class customRPA extends CustomRPABase {
  async process() {
    try {
      let excelBot = new Excel.bot();
      let rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;
      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\actionabl_testing_files\\hrt_payin.xlsx"
      );
      if (rslt.rc != 0) return rslt;

      let rowDataArray = [];

      for (let row = 6; row <= 128; row++) {
        rslt = await excelBot.readRange(`A${row}:H${row}`);
        let rowData = rslt.data[0];
        rowDataArray.push(rowData);
        // console.log(rowData);
      }
      // console.log(rowDataArray);

      // Filter rows containing 'M' or 'Z'
      let filteredRows = rowDataArray.filter(
        (rowData) => rowData.includes("M") || rowData.includes("Z")
      );
      // console.log(filteredRows);

      // Separate arrays based on filenames
      let CTHS_Data = filteredRows.filter((rowData) =>
        /^CTHS/i.test(rowData[0])
      );
      let DP_CTHS_Data = filteredRows.filter((rowData) =>
        /^DP_CTHS/i.test(rowData[0])
      );
      let EDIS_Data = filteredRows.filter((rowData) =>
        /^EDIS/i.test(rowData[0])
      );
      let HTHS_Data = filteredRows.filter((rowData) =>
        /^HTHS/i.test(rowData[0])
      );

      console.log(CTHS_Data);
      console.log(DP_CTHS_Data);
      console.log(EDIS_Data);
      console.log(HTHS_Data);

      let path =
        "C:\\Users\\Furquan\\actionabl_testing_files\\mzfiltration_excel_files\\connector_excel_files\\output1_hrt_payin.xlsx";
      rslt = await excelBot.create(path);
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.saveWorkbook(path);
      if (rslt.rc != 0) return rslt;

      let sheetsToCreate = ["CTHS", "DP_CTHS", "EDIS", "HTHS"];

      for (let sheetName of sheetsToCreate) {
        let sheetExists = false;

        for (let i = 1; i <= excelBot.workbook.worksheets.Count; i++) {
          if (excelBot.workbook.worksheets.Item(i).Name === sheetName) {
            sheetExists = true;
            break;
          }
        }

        if (!sheetExists) {
          let newWorkSheet = excelBot.workbook.worksheets.Add();
          newWorkSheet.Name = sheetName;
        }
      }

      await excelBot.switchToSheet("CTHS");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.fillRange("A1:H17", CTHS_Data);
      if (rslt.rc != 0) return rslt;

      await excelBot.switchToSheet("DP_CTHS");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.fillRange("A1:H12", DP_CTHS_Data);
      if (rslt.rc != 0) return rslt;

      await excelBot.switchToSheet("EDIS");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.fillRange("A1:H3", EDIS_Data);
      if (rslt.rc != 0) return rslt;

      await excelBot.switchToSheet("HTHS");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.fillRange("A1:H17", HTHS_Data);
      if (rslt.rc != 0) return rslt;

      // if (rslt.rc != 0) return rslt;

      rslt = await excelBot.saveWorkbook(path);
      if (rslt.rc != 0) return rslt;

      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}
module.exports = customRPA;
