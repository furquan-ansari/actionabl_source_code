let modules = global.modules;
let { CustomRPABase, Excel } = modules;
// const format = modules.require("date-fns/format");

class customRPA extends CustomRPABase {
  async process() {

let excelBot = new Excel.bot();
let rslt = await excelBot.init({ visible: true });
rslt = await excelBot.open(
  "C:\\Users\\Furquan\\actionabl_testing_files\\marksheet.xlsx"
);
let rank = [];

// Assuming you want to calculate for rows 2 to 11, adjust the range accordingly
for (let row = 2; row <= 11; row++) {
  rslt = await excelBot.readRange(`E${row}:J${row}`);
  console.log(rslt[0]);

  let sum = 0;
  let atkt = 0;

  rslt.data[0].map((E) => {
    sum += E;
    if (E < 40) {
      ++atkt;
    }
  });

  if (atkt > 0) {
    rank.push('NA');
  } else {
    rank.push(sum);
  }

  // Assuming you want to fill columns K and L for each row, adjust the columns accordingly
  rslt = await excelBot.fill(`K${row}`, sum);
  rslt = await excelBot.fill(`L${row}`, atkt);
}

// Sort the rank array (excluding 'NA' values)
let sortedRank = rank.filter(value => value !== 'NA').sort((a, b) => b - a);

// Replace 'NA' values with their corresponding ranks
for (let row = 2; row <= 11; row++) {
  if (rank[row - 2] === 'NA') {
    rslt = await excelBot.fill(`M${row}`, 'NA');
  } else {
    let rankIndex = sortedRank.indexOf(rank[row - 2]) + 1;
    rslt = await excelBot.fill(`M${row}`, rankIndex);
  }
  if (rslt.rc !== 0) return rslt;
}


    if (rslt.rc != 0) return rslt;
    let result = rslt.data;
    console.log(result);
    console.log(rank);
    return { rc: 0 };

  }

}
module.exports = customRPA;
