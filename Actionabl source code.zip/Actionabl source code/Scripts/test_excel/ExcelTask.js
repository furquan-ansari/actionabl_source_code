let modules = global.modules;
let { CustomRPABase, Excel } = modules;
let {format} = modules.require("date-fns");
let {isValid} = modules.require("date-fns/isValid");

class customRPA extends CustomRPABase {
  async process() {
    let excelBot = new Excel.bot();
    let rslt = await excelBot.init({ visible: true });

    rslt = await excelBot.open(
      "C:\\Users\\Furquan\\actionabl_testing_files\\ExcelTaskCopy.xlsx"
    );

    rslt = await excelBot.switchToSheetByNumber(2);

    let dataArray = [];

    for (let row = 2; row <= 56; row++) {
      rslt = await excelBot.readCell(`A${row}`);
      console.log(rslt.data);


      let paddedValue = String(rslt.data).padStart(7, '0');
      dataArray.push(paddedValue);

      console.log(dataArray);
      rslt = await excelBot.fill(`A${row}`, paddedValue);

    }


    let deptArray =[]
    rslt = await excelBot.switchToSheetByNumber(1);
    for (let row = 2; row <= 56; row++) {

        rslt = await excelBot.readCell(`E${row}`);
        deptArray.push(rslt.data);
        console.log(deptArray);

    }
    let dept = deptArray;
    rslt = await excelBot.switchToSheetByNumber(2);
    for(let row =2; row<=56; row++){
    rslt = await excelBot.fill(`D${row}`,dept[row-2]);
    }

    let joinDateArr =[]
    rslt = await excelBot.switchToSheetByNumber(2);

    for (let row = 2; row <= 56; row++) {
      rslt = await excelBot.readCell(`E${row}`);


      joinDateArr.push(rslt.data);
      console.log(joinDateArr);




   /*    if (isValid(new Date(rslt.data))) {
        // Use date-fns to format the date with a custom separator
        let formattedDate = format(new Date(rslt.data), "yyyy-MM-dd");
        joinDateArr.push(formattedDate);
        console.log(joinDateArr);
      } else {
        console.error(`Invalid date at cell E${row}: ${rslt.data}`);
      } */

 /*      if (typeof rslt.data === 'string') {
        let formattedDate = rslt.data.replace(/-/g, '/');
        joinDateArr.push(formattedDate);
        console.log(joinDateArr);
      } else {
        // Handle the case where rslt.data is not a string
        console.error('Invalid data type for date:', rslt.data);
      } */


      // joinDateArr.push(rslt.data);
      // console.log(joinDateArr);

/*       if (rslt.rc !=0) return rslt;

      joinDateArr = joinDateArr.map((date) => {
        if (isValid(new Date(date))) {
          return format(new Date(date), "dd/MM/yyyy");
        }
        return date; // return as is if not a valid date
      });

      // Write back the updated dates to Excel
      for (let row = 2; row <= 56; row++) {
        rslt = await excelBot.writeCell(`E${row}`, joinDateArr[row - 2]);
      } */

      /* let currentDate = new Date();

      if (rslt.data) {
        // Convert existing dates to DD/MM/YYYY format
        let formattedDate = format(new Date(rslt.data), 'dd/MM/yyyy');
        joinDateArr.push(formattedDate);
        await excelBot.fill(`E${row}`, formattedDate);
      } else {
        // If cell is empty, insert current date in DD/MM/YYYY format
        if (isValid(currentDate)) {
          let formattedCurrentDate = format(currentDate, 'dd/MM/yyyy');
          joinDateArr.push(formattedCurrentDate);
          await excelBot.fill(`E${row}`, formattedCurrentDate);
        }
      }

      console.log(joinDateArr); */
    }


    if (rslt.rc != 0) return rslt;

    let result = rslt.data;
    console.log(result);
    return { rc: 0 };
  }
}

module.exports = customRPA;
