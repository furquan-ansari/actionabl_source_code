const modules = global.modules;
let { WebRPABase, bfs, util, dataParser,CustomRPABase, Excel } = modules;


class webRPAScript extends WebRPABase{
    async process(){
        let self = this;
        let $ = self.$;
        let rslt;

        try {
        let iFrame;
        let counter = 1;
            await self.goto('https://www.saucedemo.com/v1');
                await util.wait(1000);
                await self.refreshContext();

            console.log('goto to netbanking page: done, Counter:  ' + counter);
            console.log('login frame found');
            /////////////////
            // await self.fill('cond={id:"user-name", type:"input"}',$.username);
             await self.fill('cond={id:"user-name", type:"input"}','standard_user');

            // await self.fill('cond={id:"password", type:"input"}',$.pass);
             await self.fill('cond={id:"password", type:"input"}','secret_sauce');

            await self.click('cond={id:"login-button", type:"input"}');
            try{
           await self.page.waitForSelector('cond={class: "inventory_item_name"}',{timeout:3000});
        }catch(e){
            try{
                await self.page.waitForSelector('cond={class: "inventory_item_name"}',{timeout:3000});
             }catch(e){
                 console.log("Loging Failed - "+e.message);
                 return{rc:0}
             }
            return{rc:0}
        }
        await self.page.waitForSelector('cond={class: "inventory_item_name"}')
           let Class_name= await self.page.$$('cond={class: "inventory_item_name"}');
           let Class_price= await self.page.$$('cond={class: "inventory_item_price"}');
           let Class_desc = await self.page.$$('cond={class: "inventory_item_desc"}');

            // let excelPath = $.file_path;
            let excelBot = new Excel.bot();
            rslt = await excelBot.init({ visible: true });
            if (rslt.rc != 0) return rslt;

            // rslt = await excelBot.open(excelPath);
            rslt = await excelBot.open("C:\\Users\\Furquan\\actionabl_testing_files\\swaglab.xlsx")
            if (rslt.rc != 0) return rslt;

            await excelBot.switchToSheetByNumber(2);  //provide sheet no. first create sheet into excel then we can use it

            let cellarray = ['A','B','C'];
            let header = ['Product Name','Product Price','Product Description'];

            for(let i in cellarray)
            {
                rslt = await excelBot.fill(cellarray[i].toString()+'1', header[i]);
                if (rslt.rc != 0){
                    console.log(cellarray[i].toString()+'1'+' cell not write.');
                }
            }

            for(let i in Class_price)
            {
              //  console.log(i+'A'+(parseInt(i)+2).toString());
                rslt = await excelBot.fill('A'+(parseInt(i)+2).toString(), await Class_name[i].innerHTML());
                if (rslt.rc != 0){
                    console.log('A'+(parseInt(i)+2).toString()+" cell not write.");
                }
                rslt = await excelBot.fill('B'+(parseInt(i)+2).toString(), await Class_price[i].innerHTML());
                if (rslt.rc != 0){
                    console.log('B'+(parseInt(i)+2).toString()+" cell not write.");
                }
                rslt = await excelBot.fill('C'+(parseInt(i)+2).toString(), await Class_desc[i].innerHTML());
                if (rslt.rc != 0){
                    console.log('C'+(parseInt(i)+2).toString()+" cell not write.");

                }
                console.log("Succesfully Inserted")
            }

            await self.click('cond={type:"button", str:"Open Menu"}');
            await self.click('cond={id:"logout_sidebar_link", type:"a", str:"Logout", href:"./index.html", class: "bm-item menu-item"}' );
            await util.wait(1000);

            rslt = await excelBot.closeWorkbook(true);
            if (rslt.rc != 0) return rslt;

            rslt = await excelBot.release();
            if (rslt.rc != 0) return rslt;

            ///////////////////////
            await util.wait(1000);
        } catch (e) {
            console.log('Error :- '+e.message);
        }

        return{rc : 0};
    }
}

module.exports = webRPAScript;