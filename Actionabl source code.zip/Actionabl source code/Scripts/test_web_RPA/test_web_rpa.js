const modules = global.modules;
const { WebRPABase, util } = modules;

class webRPAScript extends WebRPABase {
    async process() {
        let self = this;
        let $ = self.$;
        let rslt;
        self.stopBot = false;

        try {
            rslt = await self.login();
            if (rslt.rc != 0) return rslt;
        } catch (err) {
            console.error(err.message);
            console.error(err.stack);
            throw err;
        }

        return { rc: 0 };
    }
}

module.exports = webRPAScript;