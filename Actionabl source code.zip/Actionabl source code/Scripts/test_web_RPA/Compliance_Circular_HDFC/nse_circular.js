const modules = global.modules;
const { WebRPABase, util, Excel, bfs } = modules;
const format = modules.require('date-fns/format');
class webRPAScript extends WebRPABase {
    async process() {
        let self = this;
        let params = self.$;
        let page = self;
        let rslt;
        try {
            let excelBot = new Excel.bot();
            rslt = await excelBot.init({ visible: true });
            if (rslt.rc != 0) return rslt;

            rslt = await excelBot.open(
              "C:\\Users\\Furquan\\compliance_circular_data\\compliance_circular_urls.xlsx"
            );
            if (rslt.rc != 0) return rslt;
            await util.wait(2000);

            let nselink;
            let url = await excelBot.readCell("B2");
            if (rslt.rc != 0) return rslt;
            nselink = url.data;
            //write code here
            await self.goto(nselink, { timeout: 0 });


            // Start waiting for download before clicking. Note no await.
            const downloadPromise = self.page.waitForEvent('download');
            await self.page.locator('[class="xlsdownload ml-3"]').click();
            const download = await downloadPromise;

            // Wait for the download process to complete and save the downloaded file somewhere.
            await download.saveAs('C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\NSE/' + download.suggestedFilename());
            console.log("success");
            return { rc: 0 };
        }
        catch (e) {
            console.log(`Exception: ${e.message}`);
            return { rc: 1, msg: `Exception: ${e.message}` };
        }
    }
}

module.exports = webRPAScript;