const modules = global.modules;
const { WebRPABase, util, Excel, bfs } = modules;
const format = modules.require("date-fns/format");
class webRPAScript extends WebRPABase {
  async process() {
    let self = this;
    let $ = self.$;
    let rslt;
    let params = self.$;
    // let dpArr = [];
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        // "C:\\Users\\Furquan\\compliance_circular_data\\compliance_circular_urls.xlsx"
        "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      let cdslLink;
      await excelBot.switchToSheet("Source");
      if (rslt.rc != 0) return rslt;

      let url = await excelBot.readCell("D7");
      if (rslt.rc != 0) return rslt;
      cdslLink = url.data;
      await self.goto(cdslLink, { timeout: 0 });

      await util.wait(10000);

      await self.click('cond={type:"label", str:"DP", class: "custom-control-label"}');
            await util.wait(5000);

      // const tableHeaders = await self.page.$$eval("table thead th", ths => ths.map(th => th.textContent.trim()));
      // console.log(tableHeaders);

//////////////////////////////////////////////////////////////////////////////////////////

//       const tableRowsData = await self.page.$$eval("table tbody tr", (rows) => {
//         return rows.map((row) => {
//           const cells = Array.from(row.querySelectorAll("td"));
//           return cells.map((cell) => cell.textContent.trim());
//         });
//       });
//       // console.log(tableRowsData);

//       let data = tableRowsData;

//       function filterArrayByLatestDate(array) {
//         // Find the maximum date in the array
//         const latestDate = array.reduce((maxDate, item) => {
//           const currentDate = new Date(item[0]);
//           return currentDate > maxDate ? currentDate : maxDate;
//         }, new Date(0));

//         // Filter array based on the latest date
//         return array.filter(
//           (item) => new Date(item[0]).getTime() === latestDate.getTime()
//         );
//       }

//       // Example usage
//       const filteredData = filterArrayByLatestDate(data);
//       console.log(filteredData);

//       let latestDPData = filteredData;
//       // dpArr.push(filteredData);

//       // params.dparr = dpArr;

//       rslt = await excelBot.open(
//         // "C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\Circulars_20-02-2024.xlsx"
//         "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx"
//       );
//       if (rslt.rc != 0) return rslt;

//       await excelBot.switchToSheet("NSDL");
//       if (rslt.rc != 0) return rslt;

//       /* let dpArray = [];

//       for (let row = 5; row <= 8; row++) {
//         rslt = await excelBot.readRange(`C${row}:D${row}`);
//         let rowData = rslt.data[0];
//         dpArray.push(rowData);
//         console.log(rowData);
//       }
//       console.log(dpArray); */

//       let dpArray = [];

//       async function readRows(startRow, endRow) {
//         for (let row = startRow; row <= endRow; row++) {
//           rslt = await excelBot.readRange(`C${row}:D${row}`);
//           let rowData = rslt.data[0];
//           dpArray.push(rowData);
//           console.log(rowData);
//         }
//       }

//       // Example: read rows from 5 to 8
//       await readRows(5, 8);

//       console.log(dpArray);

//       let existingDPData = dpArray;

//       let latestDateArray1 = new Date(
//         Math.max(...latestDPData.map((item) => new Date(item[0])))
//       );

//       // Find the latest date in array2
//       let latestDateArray2 = new Date(
//         Math.max(...existingDPData.map((item) => item[0].getTime()))
//       );

//       // Create a new array based on the comparison
//       let sortedArray = [];

//       if (latestDateArray1 > latestDateArray2) {
//         sortedArray = latestDPData;
//       } else {
//         sortedArray = existingDPData;
//       }

//       console.log(sortedArray);
//       sortArr.push(sortedArray);

//       params.sortarr = sortArr;

//       // Below code used to save filteredData into excel alongwith sheet name NSDL_DP
//       /*  let path =
//         "C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\all_Compli_Cir.xlsx";
//       rslt = await excelBot.create(path);
//       if (rslt.rc != 0) return rslt;

//       rslt = await excelBot.saveWorkbook(path);
//       if (rslt.rc != 0) return rslt;

//       let sheetsToCreate = ["NSDL_DP"];

//       for (let sheetName of sheetsToCreate) {
//         let sheetExists = false;

//         for (let i = 1; i <= excelBot.workbook.worksheets.Count; i++) {
//           if (excelBot.workbook.worksheets.Item(i).Name === sheetName) {
//             sheetExists = true;
//             break;
//           }
//         }

//         if (!sheetExists) {
//           let newWorkSheet = excelBot.workbook.worksheets.Add();
//           newWorkSheet.Name = sheetName;
//         }
//       }

//       await excelBot.switchToSheet("NSDL_DP");
//       if (rslt.rc != 0) return rslt;

//       rslt = await excelBot.fillRange("A1:B4", filteredData);
//       if (rslt.rc != 0) return rslt;

//       rslt = await excelBot.saveWorkbook(path);
//       if (rslt.rc != 0) return rslt;
//  */

//       // const firstRowData = tableRowsData.length > 0 ? tableRowsData[8] : [];

//       // Log the extracted data from the first row
//       // console.log(firstRowData);

//       // Start waiting for download before clicking. Note no await.
//       // const downloadPromise = self.page.waitForEvent('download');
//       // await self.page.locator('[class="xlsdownload ml-3"]').click();
//       // const download = await downloadPromise;

//       // // Wait for the download process to complete and save the downloaded file somewhere.
//       // await download.saveAs('C:\\Users\\Furquan\\compliance_circular_data/' + download.suggestedFilename());
//       // console.log("success");

      return { rc: 0 };
    } catch (e) {
      console.log(`Exception: ${e.message}`);
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
}

module.exports = webRPAScript;
