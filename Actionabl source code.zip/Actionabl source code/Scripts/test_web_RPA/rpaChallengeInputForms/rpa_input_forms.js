const modules = global.modules;
let { WebRPABase, bfs, util, dataParser,CustomRPABase, Excel } = modules;


class webRPAScript extends WebRPABase{
    async process(){
        let self = this;
        let $ = self.$;
        let rslt;
        let params = self.$

        try {
            let value = params.dataarr      // dataarr is a field parameter declared on UI

            await self.goto('https://rpachallenge.com/');
            await util.wait(2000);

            await self.click('cond={type:"button", str:"Start", class: "waves-effect col s12 m12 l12 btn-large uiColorButton"}');
            await util.wait(2000);


            // Hard Coded
            /* or(let startRow =2; startRow<=11; startRow++){
            await self.fill('[ng-reflect-name="labelFirstName"]','Muhammad');
            await self.fill('[ng-reflect-name="labelLastName"]','Ansari');
            await self.fill('[ng-reflect-name="labelEmail"]','furquan@gmail.com');
            await self.fill('[ng-reflect-name="labelPhone"]','9089674523');
            await self.fill('[ng-reflect-name="labelAddress"]','SV,Rd,Dahisar');
            await self.fill('[ng-reflect-name="labelCompanyName"]','FeatSystems');
            await self.fill('[ng-reflect-name="labelRole"]','Developer');
            await util.wait(5000); */

           for (let startRow = 2; startRow<=11; startRow++){
            let [firstName, lastName, companyName, role, address, email, phone ] = value[startRow -2];
            await self.fill('[ng-reflect-name="labelFirstName"]',firstName);
            await self.fill('[ng-reflect-name="labelLastName"]',lastName);
            await self.fill('[ng-reflect-name="labelEmail"]',email);
            await self.fill('[ng-reflect-name="labelPhone"]',phone);
            await self.fill('[ng-reflect-name="labelAddress"]',address);
            await self.fill('[ng-reflect-name="labelCompanyName"]',companyName);
            await self.fill('[ng-reflect-name="labelRole"]',role);

            await self.click('cond={type:"input", subType:"submit", str:"Submit", class: "btn uiColorButton"}');
            await util.wait(2000);
            }

          } catch (e) {
            console.log('Error :- '+e.message);
        }

        return{rc : 0};
    }
}

module.exports = webRPAScript;