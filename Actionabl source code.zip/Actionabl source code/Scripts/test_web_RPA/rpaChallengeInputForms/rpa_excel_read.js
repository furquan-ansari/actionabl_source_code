const modules = global.modules;
let { WebRPABase, bfs, util, dataParser,CustomRPABase, Excel } = modules;


class webRPAScript extends WebRPABase{
    async process(){
        let self = this;
        let $ = self.$;
        let rslt;
        let params = self.$
        let dataArr=[]
        try {

            // Dynamic Filled Form data read from excel and put into Form Fields
            let excelBot = new Excel.bot();
            rslt = await excelBot.init({ visible: true });
            if (rslt.rc != 0) return rslt;
            rslt = await excelBot.open("C:\\Users\\Furquan\\actionabl_testing_files\\challenge.xlsx")
            if (rslt.rc != 0) return rslt;
            await util.wait(2000);

            for(let row=2; row<=11; row++ ){
            let readCell = await excelBot.readRange(`A${row}:G${row}`);
            if (rslt.rc != 0) return rslt;
            console.log(readCell.data[0]);
            dataArr.push(readCell.data[0]);

          } params.dataarr= dataArr
        }

          catch (e) {
            console.log('Error :- '+e.message);
        }

        return{rc : 0};
    }
}

module.exports = webRPAScript;