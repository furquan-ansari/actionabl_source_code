const { WebRPABase, util, winAppDriver,Excel,bfs} = global.modules;
const { WinAppDriver } = winAppDriver;

class webRPAScript extends WebRPABase {
    async process() {
        let self = this;
        let $ = self.$;
        let rslt;

        try
        {
            await self.page.goto('https://rpachallenge.com/assets/rpaStockMarket/index.html');
            console.log('Opening Browser');
            await util.wait(5000);
            await self.refreshContext();

           /*  await self.page.selectOption('cond={id:"country", type:"select"}','Exenon UI  Pharma.');
            await self.click('cond={type:"input", subType:"image"}');
            await self.refreshContext();
            let value = await self.page.innerHTML('cond={id:"cnt", type:"span"}');

            console.log('Value for Exenon UI  Pharma :- '+value);

            await util.wait(5000);

            await self.page.selectOption('cond={id:"country", type:"select"}','WEX Academy Inc.');
            await self.click('cond={type:"input", subType:"image"}');
            await self.refreshContext();
            let value1 = await self.page.innerHTML('cond={id:"cnt", type:"span"}');

            console.log('Value for WEX Academy Inc:- '+value1);

            await util.wait(2000);

            await self.page.selectOption('cond={id:"country", type:"select"}','Exxon RPA Corp.');
            await self.click('cond={type:"input", subType:"image"}');
            await self.refreshContext();
            let value2 = await self.page.innerHTML('cond={id:"cnt", type:"span"}');

            console.log('Value for Exxon RPA Corp :- '+value2); */

            await util.wait(5000);

            // below logic for the for loop

            // Inserting data into Excel Logic:-
            let excelBot = new Excel.bot();
            rslt = await excelBot.init({ visible: true });
            if (rslt.rc != 0) return rslt;

            // rslt = await excelBot.open(excelPath);
            rslt = await excelBot.open("C:\\Users\\Furquan\\actionabl_testing_files\\stocks.xlsx")
            if (rslt.rc != 0) return rslt;
            await util.wait(2000);

            // await excelBot.switchToSheetByNumber(1);  //provide sheet no. first create sheet into excel then we can use it

            let cellarray = ['A','B','C'];
            let header = [];
            let stocksPrice = [];

            let array = await self.page.$$('cond={id:"country", type:"select"}>>option');
            for(let i=1;i<array.length;i++){
                let sel = await array[i].innerHTML();
                await self.page.selectOption('cond={id:"country"}',sel);
                header.push(sel);
                await self.click('cond={type:"input", subType:"image"}');
                await self.refreshContext();
                let data = await self.page.innerHTML('cond={id:"cnt", type:"span"}');
                console.log(sel+' Price is ' + data)

                await util.wait(2000);
                stocksPrice.push(data);
            }


            /* for(let i in cellarray)
            {
                rslt = await excelBot.fill(cellarray[i].toString()+'1', header[i]);
                if (rslt.rc != 0){
                    console.log(cellarray[i].toString()+'1'+' cell not write.');
                }
            }

            for (let i in cellarray) {
                rslt = await excelBot.fill(cellarray[i].toString() + '2', stocksPrice[i]);
                if (rslt.rc != 0) {
                    console.log(cellarray[i].toString() + '2' + ' cell not write.');
                }
            } */

            // combine above for in loop operation into single one
            for (let i in cellarray) {
                // First operation
                rslt = await excelBot.fill(cellarray[i].toString() + '1', header[i]);
                if (rslt.rc != 0) {
                    console.log(cellarray[i].toString() + '1' + ' cell not write.');
                }

                // Second operation
                rslt = await excelBot.fill(cellarray[i].toString() + '2', stocksPrice[i]);
                if (rslt.rc != 0) {
                    console.log(cellarray[i].toString() + '2' + ' cell not write.');
                }
            }


            await util.wait(4000)

            rslt = await excelBot.closeWorkbook(true);
            if (rslt.rc != 0) return rslt;

            rslt = await excelBot.release();
            if (rslt.rc != 0) return rslt;


            return { rc: 0 };

        }
        catch(e)
        {
            console.log('Exception Message :- '+e.Message);
           // return { rc : 1,Message : e.Message}
        }


    }
}

module.exports = webRPAScript;




