const modules = global.modules;
let { WebRPABase, bfs, util, dataParser,CustomRPABase, Excel } = modules;


class webRPAScript extends WebRPABase{
    async process(){
        let self = this;
        let $ = self.$;
        let rslt;

        try {
            await self.goto('https://rpachallenge.com/');
            await util.wait(2000);

            await self.click('cond={type:"button", str:"Start", class: "waves-effect col s12 m12 l12 btn-large uiColorButton"}');
            await util.wait(2000);

            // Hard Coded Form data
            /* await self.fill('[ng-reflect-name="labelFirstName"]','Muhammad');
            await self.fill('[ng-reflect-name="labelLastName"]','Ansari');
            await self.fill('[ng-reflect-name="labelEmail"]','furquan@gmail.com');
            await self.fill('[ng-reflect-name="labelPhone"]','9089674523');
            await self.fill('[ng-reflect-name="labelAddress"]','SV,Rd,Dahisar');
            await self.fill('[ng-reflect-name="labelCompanyName"]','FeatSystems');
            await self.fill('[ng-reflect-name="labelRole"]','Developer');
            await util.wait(5000); */

            // properties
            /* let Class_FirstName= await self.page.$$('[ng-reflect-name="labelFirstName"]');
            let Class_LastName= await self.page.$$('[ng-reflect-name="labelLastName"]');
            let Class_Email= await self.page.$$('[ng-reflect-name="labelEmail"]');
            let Class_Phone= await self.page.$$('[ng-reflect-name="labelPhone"]');
            let Class_Address= await self.page.$$('[ng-reflect-name="labelAddress"]');
            let Class_CompanyName= await self.page.$$('[ng-reflect-name="labelCompanyName"]');
            let Class_Role= await self.page.$$('[ng-reflect-name="labelRole"]'); */

            // Dynamic Filled Form data read from excel and put into Form Fields
            for(let row=2; row<=11; row++ ){
            let excelBot = new Excel.bot();
            rslt = await excelBot.init({ visible: true });
            if (rslt.rc != 0) return rslt;
            rslt = await excelBot.open("C:\\Users\\Furquan\\actionabl_testing_files\\challenge.xlsx")
            if (rslt.rc != 0) return rslt;
            await util.wait(2000);

            let readCell = await excelBot.readRange(`A${row}:G${row}`);
            if (rslt.rc != 0) return rslt;
            console.log(readCell.data[0]);

            let [firstName, lastName, companyName, role, address, email, phone ] = readCell.data[0];
            await self.fill('[ng-reflect-name="labelFirstName"]',firstName);
            await self.fill('[ng-reflect-name="labelLastName"]',lastName);
            await self.fill('[ng-reflect-name="labelEmail"]',email);
            await self.fill('[ng-reflect-name="labelPhone"]',phone);
            await self.fill('[ng-reflect-name="labelAddress"]',address);
            await self.fill('[ng-reflect-name="labelCompanyName"]',companyName);
            await self.fill('[ng-reflect-name="labelRole"]',role);

            await self.click('cond={type:"input", subType:"submit", str:"Submit", class: "btn uiColorButton"}');
            await util.wait(2000);
            }

          } catch (e) {
            console.log('Error :- '+e.message);
        }

        return{rc : 0};
    }
}

module.exports = webRPAScript;