let modules = global.modules;
let { CustomRPABase, bfs } = modules;
// const format = modules.require("date-fns/format");

class customRPA extends CustomRPABase {
  async process() {
           // Below code to fetch data from file
        let self = this;
        let params = self.$;
         let rslt = await bfs.readFile(params.FilePath);  // for dynamic value
        // let rslt = await bfs.readFile('C:\\Users\\Furquan\\VS Codes\\PDF\\output_base64.txt'); // for hardcore value
        if (rslt.rc != 0) return rslt;
        let fileData = rslt.data;
        console.log(fileData)
        return { rc: 0 };

    /*             // Below code to Check if directory exists
        // let self = this;
        // let params = self.$;
        // let rslt = await bfs.isDirEmpty(params.FilePath);  // for dynamic value
        let rslt = await bfs.dirExists('C:\\Users\\Furquan\\VS Codes\\PDF');
        if (rslt.rc != 0) return rslt;

        let doesDirExist = rslt.data;
        console.log(doesDirExist);
        return { rc: 0 }; */

    /*         // Below code to Read directory
        let rslt = await bfs.readDir('C:\\Users\\Furquan\\VS Codes\\PDF');
        if (rslt.rc != 0) return rslt;

        let files = rslt.data;
        console.log(files);
        return { rc: 0 }; */

    /*          // Below code to Create Directory
        let rslt = await bfs.mkDir('C:\\Users\\Furquan\\VS Codes\\PDF\\actionabl_test_1',true);
        if (rslt.rc != 0) return rslt;
        let result = rslt.data;
        console.log(result);
        return { rc: 0 }; */

    /*         // Below code to copy directory
        let rslt = await bfs.copyDir('C:\\Users\\Furquan\\VS Codes\\PDF\\actionabl_test_1', 'C:\\Users\\Furquan\\VS Codes\\PDF', true);
        if (rslt.rc != 0) return rslt;
        let result = rslt.data;
        console.log(result);
        return { rc: 0 }; */

    /*          // Below code to delete directory
        let rslt = await bfs.deleteDir('C:\\Users\\Furquan\\VS Codes\\PDF\\actionabl_test',true);
        if (rslt.rc != 0) return rslt;
        let result = rslt.data;
        console.log(result);
        return { rc: 0 }; */

    /*    // Below code for ensure folder if it's not present then it'll create automatically

        let rslt = await bfs.ensureFolder('C:\\Users\\Furquan\\VS Codes\\PDF\\actionabl_test_1');
        if (rslt.rc != 0) return rslt;
        let result = rslt.data;
        console.log(result);
        return { rc: 0 }; */

    /*         // Below code to get file stats
        let rslt = await bfs.fileStat('C:\\Users\\Furquan\\VS Codes\\PDF');
        if (rslt.rc != 0) return rslt;
        let stats = rslt.data;
        console.log(stats); */

/*     // Below code to check if file exists
    let rslt = await bfs.fileExists('C:\\Users\\Furquan\\VS Codes\\PDF\\output_base64.txt');
    if (rslt.rc != 0) return rslt;
    let doesExist = rslt.data;
    console.log(doesExist); */

/*     // Below code for append

    let rslt = await bfs.appendFile('C:\Users\Furquan\actionabl_testing_files\actionabl_test_file', 'Hello');
    if (rslt.rc != 0) return rslt;
    let data = rslt.data;
    console.log(data);
    return { rc: 0 }; */

  }
}

module.exports = customRPA;
