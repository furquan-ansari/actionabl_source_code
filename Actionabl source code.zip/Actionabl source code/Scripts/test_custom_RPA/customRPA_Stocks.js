let modules = global.modules;
let{CustomRPABase,Excel,util} = modules;
const playwright = modules.require('playwright');

class CustomRPA extends CustomRPABase {
    async process() {
        let self = this;
        let $ = self.$;
        let rslt;

        try
        {

                const browser = await playwright.chromium.launch({
                  channel: 'msedge', headless:false
                });
                const context = await browser.newContext();
                const page = await context.newPage();
                await page.goto('https://rpachallenge.com/assets/rpaStockMarket/index.html');
                // await page.screenshot({ path: 'example.png' });
                // await browser.close();

            // Inserting data into Excel Logic:-
            let excelBot = new Excel.bot();
            rslt = await excelBot.init({ visible: true });
            if (rslt.rc != 0) return rslt;

            // rslt = await excelBot.open(excelPath);
            rslt = await excelBot.open("C:\\Users\\Furquan\\actionabl_testing_files\\stocks.xlsx")
            if (rslt.rc != 0) return rslt;
            await util.wait(2000);


            let ele = await page.locator('[id="country"]').allInnerTexts()
            let dropdowndata = ele[0].split('\n');
            let preMarketPrice = [];

            for (let index = 1; index < dropdowndata.length; index++) {
              const element = dropdowndata[index]//.innerHTML();
              console.log(element)
              await page.locator("[id='country']").selectOption( element)
              await page.locator("[type='image']").click();
              let val = await page.locator("[id='cnt']").innerHTML();
              preMarketPrice.push(val)

            }
            console.log(preMarketPrice)

            return { rc: 0 };

              }

        catch(e)
        {
            console.log('Exception Message :- '+e.Message);
           // return { rc : 1,Message : e.Message}
        }


    }
}

module.exports = CustomRPA;




