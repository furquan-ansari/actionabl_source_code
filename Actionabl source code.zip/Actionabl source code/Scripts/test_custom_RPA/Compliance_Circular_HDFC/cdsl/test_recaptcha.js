const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { chromium } = modules.require('playwright');
const Captcha = require("2captcha");


class webRPAScript extends CustomRPABase {
async process ()  {

    try{
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();

  // Insert your API key here
  const solver = new Captcha.Solver("c0a3c9b963392d177649a7d6d6ff779ed8c0c0a4");
// Call ReCaptcha Website
const websiteUrl = "https://patrickhlauke.github.io/recaptcha/";
await page.goto(websiteUrl);

// Wait for the CAPTCHA element to load
const captchaFrame = await page.waitForSelector("iframe[src*='recaptcha/api2']");

// Switch to the CAPTCHA iframe
const captchaFrameContent = await captchaFrame.contentFrame();

// Wait for the CAPTCHA checkbox to appear
const captchaCheckbox = await captchaFrameContent.waitForSelector("#recaptcha-anchor");

// Click the CAPTCHA checkbox
await captchaCheckbox.click();
 // Wait for the CAPTCHA challenge to be solved by 2Captcha
 const captchaResponse = await solver.recaptcha("6Ld2sf4SAAAAAKSgzs0Q13IZhY02Pyo31S2jgOB5", websiteUrl);

 // Fill in the CAPTCHA response and submit the form
 const captchaInput = await captchaFrameContent.waitForSelector("#g-recaptcha-response");
 await captchaInput.evaluate((input, captchaResponse) => {
   input.value = captchaResponse;
 }, captchaResponse);
 await captchaFrameContent.waitForSelector("button[type='submit']").then((button) => button.click());

 // Wait for the page to navigate to the next page
 await page.waitForNavigation();

 console.log("CAPTCHA solved successfully!");

 await browser.close();
}
catch(err){
    console.error(err.message);
    throw err;
}
}}
module.exports = webRPAScript;