// const modules = global.modules;
// const { CustomRPABase, util, Excel } = modules;
// const { firefox } = modules.require("playwright");

// class webRPAScript extends CustomRPABase {
//   async process() {
//     let self = this;
//     let rslt;
//     let params = self.$;
//     let sortArr = [];
//     try {
//       let excelBot = new Excel.bot();
//       rslt = await excelBot.init({ visible: true });
//       if (rslt.rc != 0) return rslt;

//       rslt = await excelBot.open(
//         "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
//       );
//       if (rslt.rc != 0) return rslt;
//       await util.wait(2000);

//       await excelBot.switchToSheet("Source");
//       if (rslt.rc != 0) return rslt;

//       let cdslLink;
//       let url = await excelBot.readCell("D8");
//       if (rslt.rc != 0) return rslt;
//       cdslLink = url.data;

//       const browser = await firefox.launch({
//         headless: false,
//         acceptDownloads: true,
//       });
//       // const context = await browser.newContext();
//       // const page = await context.newPage();
//       const page = await browser.newPage();
//       await page.goto(cdslLink);
//       await util.wait(2000);

//       // await page.mouse.move(10, 20);
//       // await util.wait(2000);

//       const rtaRadioBtn = 'label[for="rtaselect"]';

//       await page.waitForSelector(rtaRadioBtn);
//       await util.wait(5000);
//       await page.click(rtaRadioBtn);

//       // await page.mouse.move(20, 30);
//       // await util.wait(2000);

//       const notRobotBtn = "iframe[title=reCAPTCHA]";
//       await page.waitForSelector(notRobotBtn);
//       await page.mouse.down();
//       await util.wait(5000);
//       await page.click(notRobotBtn);
//       await util.wait(3000);

//       const submit = 'input[id="btnSubmit"]';
//       await page.waitForSelector(submit);
//       await util.wait(5000);
//       await page.click(submit);
//       await util.wait(2000);

//       const tableRowsData = await page.$$eval("table tbody tr", (rows) => {
//         return rows.map((row) => {
//           const cells = Array.from(row.querySelectorAll("td"));
//           return cells.map((cell) => cell.textContent.trim());
//         });
//       });
//       // console.log(tableRowsData);

//       let circular = tableRowsData;

//       const filteredArraysRTA = circular.filter((subArray) =>
//         subArray.some(
//           (item) => typeof item === "string" && item.includes("RTA")
//         )
//       );
//       console.log(filteredArraysRTA);

//       rslt = await excelBot.open(
//         // "C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\Circulars_20-02-2024.xlsx"
//         "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx"
//       );
//       if (rslt.rc != 0) return rslt;

//       await excelBot.switchToSheet("CDSL");
//       if (rslt.rc != 0) return rslt;

//       let rtaArray = [];

//       async function readRows(startRow, endRow) {
//         for (let row = startRow; row <= endRow; row++) {
//           rslt = await excelBot.readRange(`C${row}:F${row}`);
//           let rowData = rslt.data[0];
//           rtaArray.push(rowData);
//           console.log(rowData);
//         }
//       }

//       // Example: read rows from 10
//       await readRows(10, 10);

//       console.log(rtaArray);

//       let latestRTAData = filteredArraysRTA;
//       let existingRTAData = rtaArray;

//       let [, maxi] = existingRTAData[0][1].split("-");

//       let filtered = latestRTAData.filter((subArray) => {
//         return subArray[1].split("-").slice(-1) > maxi;
//       });

//       if (filtered.length === 0) {
//         // If latestRTAData has a minimum range, console existingDPData as the filtered output
//         console.log(existingRTAData);
//       } else {
//         console.log(filtered);
//         sortArr.push(filtered);
//       }

//       params.sort_cdsl_rta_custom_arr = sortArr;
//     } catch (err) {
//       console.error(err.message);
//       console.error(err.stack);
//       throw err;
//     }
//     return { rc: 0 };
//   }
// }
// module.exports = webRPAScript;



//////////////////////////////////////////////////////////////////////////////////


const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { firefox } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("Source");
      if (rslt.rc != 0) return rslt;

   // Below code used for getting  dynamic url from excel
   rslt = await excelBot.readRange("B2:B24");
   let Source = rslt.data.flat();

   rslt = await excelBot.readRange("D2:D24");
   let Url = rslt.data.flat();

   function geturl (source, url){
     let result = source.map((el,index)=>{
       return {sources:el, index, url:url[index]}
     });
     return result;
   }
   let connectUrl = geturl(Source, Url);
   console.log("Below array for URL getting from Excel sheet>>>>>>");
   console.log(connectUrl);
   rslt = await excelBot.readRange('A2:A24');
   let toMatch = rslt.data;
   // console.log(toMatch);

      const browser = await firefox.launch({
        headless: false,
        acceptDownloads: true,
      });

      //To clear cookies and cache
      const context = await browser.newContext();

      // Clear cookies and cache
       await context.clearCookies();

      // const context = await browser.newContext();
      // const page = await context.newPage();
      const page = await browser.newPage();
      await page.goto(connectUrl[6].url);
      await util.wait(2000);



      // await page.mouse.move(10, 20);
      // await util.wait(2000);

      const rtaRadioBtn = 'label[for="rtaselect"]';

      await page.waitForSelector(rtaRadioBtn);
      await util.wait(5000);
      await page.click(rtaRadioBtn);

      await page.mouse.move(20, 30);
      await util.wait(2000);

      const notRobotBtn = "iframe[title=reCAPTCHA]";
      await page.waitForSelector(notRobotBtn);
      // await page.mouse.down();
      await util.wait(5000);
      await page.click(notRobotBtn);
      await util.wait(3000);

      const submit = 'input[id="btnSubmit"]';
      await page.waitForSelector(submit);
      await util.wait(5000);
      await page.click(submit);
      await util.wait(2000);

      // Header Data:
      const tableHeaders = await page.$$eval("table thead th", ths => ths.map(th => th.textContent.trim()));
      //  console.log(tableHeaders);

      const trimmedTableHeadData = tableHeaders.slice(16);
      console.log(trimmedTableHeadData);

    // Table Data:
      const tableRowsData = await page.$$eval("table tbody tr", (rows) => {
        return rows.map((row) => {
          const cells = Array.from(row.querySelectorAll("td"));
          return cells.map((cell) => cell.textContent.trim());
        });
      });
      // console.log(tableRowsData);

      const trimmedTableRowData = tableRowsData.slice(12);
      console.log(trimmedTableRowData);

    // Combined Header and Table Data:

    // Combine Header and Table Data
    const combinedData = trimmedTableRowData.map((rowData) => {
      const combinedRow = {};
      rowData.forEach((cell, index) => {
        combinedRow[trimmedTableHeadData[index]] = cell;
      });
      return combinedRow;
    });

    console.log(combinedData);

      // let circular = tableRowsData;

      // const filteredArraysRTA = circular.filter((subArray) =>
      //   subArray.some(
      //     (item) => typeof item === "string" && item.includes("RTA")
      //   )
      // );
      // console.log(filteredArraysRTA);

      // rslt = await excelBot.open(
      //   // "C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\Circulars_20-02-2024.xlsx"
      //   "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx"
      // );
      // if (rslt.rc != 0) return rslt;

      // await excelBot.switchToSheet("CDSL");
      // if (rslt.rc != 0) return rslt;

      // let rtaArray = [];

      // async function readRows(startRow, endRow) {
      //   for (let row = startRow; row <= endRow; row++) {
      //     rslt = await excelBot.readRange(`C${row}:F${row}`);
      //     let rowData = rslt.data[0];
      //     rtaArray.push(rowData);
      //     console.log(rowData);
      //   }
      // }

      // // Example: read rows from 10
      // await readRows(10, 10);

      // console.log(rtaArray);

      // let latestRTAData = filteredArraysRTA;
      // let existingRTAData = rtaArray;

      // let [, maxi] = existingRTAData[0][1].split("-");

      // let filtered = latestRTAData.filter((subArray) => {
      //   return subArray[1].split("-").slice(-1) > maxi;
      // });

      // if (filtered.length === 0) {
      //   // If latestRTAData has a minimum range, console existingDPData as the filtered output
      //   console.log(existingRTAData);
      // } else {
      //   console.log(filtered);
      //   sortArr.push(filtered);
      // }

      // params.sort_cdsl_rta_custom_arr = sortArr;
    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;
