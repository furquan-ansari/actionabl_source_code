const modules = global.modules;
const { bfs, CustomRPABase,util} = modules;
const path = require('path');
const format = modules.require('date-fns/format');
const { firefox } = modules.require('playwright');

class customRPA extends CustomRPABase {
    async process() {
        let self = this;
        let params = self.$;
        let rslt;
        try {


            const browser = await firefox.launch({ headless: false });
            const page = await browser.newPage();
            await page.goto('https://www.amfiindia.com/distributor-corner/circulars-and-announcements/circulars', { waituntil: 'load', timeout: 0 });
            // await util.wait(5000);
            // const elements = await page.waitForSelector('.full-content', { timeout: 0 });
            // const rows = await elements.$$eval('table tr td', tds => {
            //     return tds.map(td => td.innerText);
            // });
            // console.log(rows);
            let tableData = await page.$$eval("//*[@id='CenterContent']/div[2]/div/div[1]/table/tbody/tr", (rows) => {
                return rows.map((row) => {
                  const cells = Array.from(row.querySelectorAll("td"));
                  const tableHeaders = ['Circular Reference', 'Subject', 'Date of Circular'];
                  let rowData={};
                  cells.forEach((cell,index)=>{
                      let anchor = cell.querySelectorAll('a');
                      let href ="";
                      if(anchor.length>0){
                        href = "https://www.amfiindia.com/" +anchor[0].getAttribute('href');
                      }
                      if(tableHeaders[index] !=undefined)
                        rowData[tableHeaders[index]]={value:cell.textContent.trim(), href: href};
                  })

                  return rowData;
                });
              });
              console.log(tableData);

            await browser.close();
          console.log('success');
            return { rc: 0 };

        }
            catch(e){

            console.log(`Exception: ${e.message}`);
            return { rc: 1, msg: `Exception: ${e.message}`};
        }
    }
}
 module.exports = customRPA;