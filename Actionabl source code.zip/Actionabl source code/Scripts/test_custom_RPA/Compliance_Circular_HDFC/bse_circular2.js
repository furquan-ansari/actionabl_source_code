const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { firefox } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("Source");
      if (rslt.rc != 0) return rslt;

 /*      let nseLink;
      let url = await excelBot.readCell("D3");
      if (rslt.rc != 0) return rslt;
      nseLink = url.data; */

      rslt = await excelBot.readRange("B2:B24");
      let Source = rslt.data.flat();

      rslt = await excelBot.readRange("D2:D24");
      let Url = rslt.data.flat();

      function geturl (source, url){
        let result = source.map((el,index)=>{
          return {sources:el, index, url:url[index]}
        });
        return result;
      }
      let connectUrl = geturl(Source, Url);
      console.log(connectUrl);
      rslt = await excelBot.readRange('A2:A24');
      let toMatch = rslt.data;
      // console.log(toMatch);

      const browser = await firefox.launch({
        headless: false,
        acceptDownloads: true,
      });

      const page = await browser.newPage();
      await page.goto(connectUrl[1].url);
      await util.wait(5000);

      let tableData = await page.$$eval("table tbody tr tr", (rows) => {
        return rows.slice(2).map((row) => {
          const cells = Array.from(row.querySelectorAll("td"));
          const tableHeaders = ['Notice No', 'Subject', 'Segment Name', 'Category Name', 'Department'];
          let rowData={};
          cells.forEach((cell,index)=>{
              let anchor = cell.querySelectorAll('a');
              let href ="";
              if(anchor.length>0){
                href = "https://www.bseindia.com" +anchor[0].getAttribute('href');
              }
              if(tableHeaders[index] !=undefined)
                rowData[tableHeaders[index]]={value:cell.textContent.trim(), href: href};
          })

          return rowData;
        });
      });
      console.log(tableData);

      // Header Data:
    //   const tableHeaders = await page.$$eval("table tbody tr th", ths => ths.map(th => th.textContent.trim()));
    //   console.log(tableHeaders);

    //   //Below to code to get hyperlink of Subject
    // //    const tableRowsData = await page.$$eval("table tbody tr tr", (rows) => {
    // //     return rows.map((row) => {
    // //       const cells = Array.from(row.querySelectorAll("td"));
    // //       return cells.map((cell) => {
    // //         const textContent = cell.textContent.trim();
    // //         const anchorTag = cell.querySelector("a"); // Select the anchor tag within the cell

    // //         if (anchorTag) {
    // //           const attachmentLink = anchorTag.getAttribute("href");
    // //           return 'https://www.bseindia.com'+ attachmentLink ;
    // //         } else {
    // //           return textContent;
    // //         }
    // //       });
    // //     });
    // //   });

    // //   console.log(tableRowsData);

    // //   const trimmedTableRowsData = tableRowsData.slice(2);

    // // console.log(trimmedTableRowsData);



    //   //Below to code to get only Text of Subject
    //   // Table Data
    //   const tableRowsData = await page.$$eval("table tbody tr tr", (rows) => {
    //     return rows.map((row) => {
    //         const cells = Array.from(row.querySelectorAll("td"));
    //         return cells.map((cell) => cell.textContent.trim());
    //     });
    // });

    // // Remove the first two indexes
    // const trimmedTableRowsData = tableRowsData.slice(2);

    // console.log(trimmedTableRowsData);

    // // Combine Header and Table Data:
    // const combinedData = trimmedTableRowsData.map((rowData) => {
    //   const combinedRow = {};
    //   rowData.forEach((cell, index) => {
    //     combinedRow[tableHeaders[index]] = cell;
    //   });
    //   return combinedRow;
    // });

    // console.log(combinedData);


    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;