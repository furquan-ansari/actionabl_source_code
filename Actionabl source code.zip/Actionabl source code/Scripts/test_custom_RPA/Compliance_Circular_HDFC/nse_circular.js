/* let modules = global.modules;
let { CustomRPABase, Excel, util } = modules;
let {chromium} = modules.require("playwright");

class CustomRPA extends CustomRPABase {
  async process() {
    // let self = this;
    let rslt;

    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\compliance_circular_data\\compliance_circular_urls.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      let nselink;
      let url = await excelBot.readCell("B2");
      if (rslt.rc != 0) return rslt;
      nselink = url.data;
      // console.log(nselink);

      const browser = await chromium.launch({
        channel: "msedge",
        headless: false,
        acceptDownloads: true
      });
      // const context = await browser.newContext();
      // const page = await context.newPage();
      const page = await browser.newPage();
      await page.goto(nselink);
      await util.wait(5000);

      // Start waiting for download before clicking. Note no await.
      const downloadPromise = page.waitForEvent("download");
      await page.locator('[class="xlsdownload ml-3"]').click();
      const download = await downloadPromise;

      // Wait for the download process to complete and save the downloaded file somewhere.
      await download.saveAs(
        "C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular" +
          download.suggestedFilename()
      );
      console.log("success>>>>");

      return { rc: 0 };
    } catch (e) {
      console.log("Exception Message :- " + e.Message);
      // return { rc : 1,Message : e.Message}
    }
  }
}

module.exports = CustomRPA; */


///////////////////////////////////////////////////////////////////////////

/* 
const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const {chromium }= modules.require('playwright');

class webRPAScript extends CustomRPABase {
    async process() {
        let self = this;
        let rslt;

        try {
                const browser = await chromium.launch({ headless: false , acceptDownloads: true });
                const page = await browser.newPage();

                //Navigate to your webpage
                await page.goto("https://www.nseindia.com/resources/exchange-communication-circulars");
                // cond={type:'i', class: 'fa fa-download iconfont'}

                const downloadPromise = page.waitForEvent('downloadCSV()');
                await page.locator('[class="xlsdownload ml-3"]').click();
                const download = await downloadPromise;

                // Wait for the download process to complete and save the downloaded file somewhere.
                await download.saveAs("C:\\Users\\Furquan\\compliance_circular_data" + download.suggestedFilename());
                console.log('done')

        } catch (err) {
            console.error(err.message);
            console.error(err.stack);
            throw err;

        }
        return { rc: 0 };
    }
}
module.exports = webRPAScript; */

/////////////////////////////////////////////////////////////////////////////////////////////

// Finally working code only for firefox browser to download excel file properly but not with chromium
/* 
const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { firefox }= modules.require('playwright');


class webRPAScript extends CustomRPABase {
    async process() {

        let self = this;
        let rslt;

        try {

          let excelBot = new Excel.bot();
          rslt = await excelBot.init({ visible: true });
          if (rslt.rc != 0) return rslt;
    
          rslt = await excelBot.open(
            "C:\\Users\\Furquan\\compliance_circular_data\\compliance_circular_urls.xlsx"
          );
          if (rslt.rc != 0) return rslt;
          await util.wait(2000);
    
          let nselink;
          let url = await excelBot.readCell("B2");
          if (rslt.rc != 0) return rslt;
          nselink = url.data;
          // console.log(nselink);
    
          const browser = await firefox.launch({
            headless: false,
            acceptDownloads: true
          });
          // const context = await browser.newContext();
          // const page = await context.newPage();
          const page = await browser.newPage();
          await page.goto(nselink);
          await util.wait(5000);

                // const browser = await firefox.launch({ headless: false , acceptDownloads: true });
                // const page = await browser.newPage();

                //Navigate to your webpage
                //await page.goto("https://www.bseindia.com/markets/MarketInfo/NoticesCirculars.aspx?id=0&txtscripcd=&pagecont=&subject=");
                // await page.goto("https://www.nseindia.com/resources/exchange-communication-circulars");

                const downloadPromise = page.waitForEvent('download');
                //await page.locator("[id='ContentPlaceHolder1_lnkDownload']").click();
                await page.locator('[class="xlsdownload ml-3"]').click();
                const download = await downloadPromise;


                // Wait for the download process to complete and save the downloaded file somewhere.
                let filepath = "C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular/" + download.suggestedFilename();
                await download.saveAs(filepath);
                console.log('done')

                // let excelBot = new Excel.bot();
                // rslt = await excelBot.init({ visible: true });
                // if (rslt.rc != 0) return rslt;

                // rslt = await excelBot.open(filepath);
                // if (rslt.rc != 0) return rslt;

                // let Col = excelBot.worksheet.Cells.SpecialCells(
                //     11 xlCellTypeLastCell
                //   ).Column;
                //   let Row = excelBot.worksheet.Cells.SpecialCells(
                    // 11 xlCellTypeLastCell
                //   ).Row;

                //   function numToChar(num) {
                //     let char = "";
                //     while (num > 0) {
                //       let modulo = (num - 1) % 26;
                //       char = String.fromCharCode(65 + modulo) + char;
                //       num = Math.floor((num - modulo) / 26);
                //     }
                //     return char;
                //   }

                //   let range = "A1:" + numToChar(Col) + Row;

                //   rslt = await excelBot.readRange(range);
                //   let Excel_data = rslt.data;

                //   console.log(Excel_data)

        } catch (err) {
            console.error(err.message);
            console.error(err.stack);
            throw err;

        }
        return { rc: 0 };
    }
}
module.exports = webRPAScript; */


//////////////////////////////////////////////////////////////////////////////////////

const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { firefox } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("Source");
      if (rslt.rc != 0) return rslt;

/*       let nseLink;
      let url = await excelBot.readCell("D2");
      if (rslt.rc != 0) return rslt;
      nseLink = url.data; */

  /*     rslt =  await excelBot.readRange("A1:L24");

      if(rslt.rc != 0) return rslt;
      let datas = rslt.data;

      const headers= datas[0];

      const jsonData = datas.slice(1).map(row =>{
        const obj ={};
        headers.forEach((header,index)=>{
          obj[header] = row[index];
        });
        return obj;
      })
const jsonString = JSON.stringify(jsonData, null,2);
console.log(jsonString); */
// console.log(jsonString[1]["Url_To_Download_Circulars"]);

      rslt = await excelBot.readRange("B2:B24");
      let Source = rslt.data.flat();

      rslt = await excelBot.readRange("D2:D24");
      let Url = rslt.data.flat();

      function geturl (source, url){
        let result = source.map((el,index)=>{
          return {sources:el, index, url:url[index]}
        });
        return result;
      }
      let connectUrl = geturl(Source, Url);
      console.log(connectUrl);
      rslt = await excelBot.readRange('A2:A24');
      let toMatch = rslt.data;
      // console.log(toMatch);

      const browser = await firefox.launch({
        headless: false,
        acceptDownloads: true,
      });

      const page = await browser.newPage();
      await page.goto(connectUrl[0].url);
      await util.wait(5000);

      // Header Data:
      const tableHeaders = await page.$$eval("table thead th", ths => ths.map(th => th.textContent.trim()));
      console.log(tableHeaders);

      const tableRowsData = await page.$$eval("table tbody tr", (rows) => {
        return rows.map((row) => {
          const cells = Array.from(row.querySelectorAll("td"));
          return cells.map((cell) => {
            const textContent = cell.textContent.trim();
            const anchorTag = cell.querySelector("a"); // Select the anchor tag within the cell

            if (anchorTag) {
              const attachmentLink = anchorTag.getAttribute("href");
              return  attachmentLink ;
            } else {
              return textContent;
            }
          });
        });
      });

      console.log(tableRowsData);



      // Table Data
      /* const tableRowsData = await page.$$eval("table tbody tr ", (rows) => {
        return rows.map((row) => {
          const cells = Array.from(row.querySelectorAll("td"));
          return cells.map((cell) => cell.textContent.trim());
        });
      });
      console.log(tableRowsData);
 */
      // Combine Header and Table Data
      const combinedData = tableRowsData.map((rowData) => {
        const combinedRow = {};
        rowData.forEach((cell, index) => {
          combinedRow[tableHeaders[index]] = cell;
        });
        return combinedRow;
      });

      console.log(combinedData);

      // let nseCircular = tableRowsData;


      // rslt = await excelBot.open(
      //   // "C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\Circulars_20-02-2024.xlsx"
      //   "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx"
      // );
      // if (rslt.rc != 0) return rslt;

      // await excelBot.switchToSheet("NSE");
      // if (rslt.rc != 0) return rslt;

      // let nseArray = [];

      // async function readRows(startRow, endRow) {
      //   for (let row = startRow; row <= endRow; row++) {
      //     rslt = await excelBot.readRange(`C${row}:G${row}`);
      //     let rowData = rslt.data[0];
      //     nseArray.push(rowData);
      //     console.log(rowData);
      //   }
      // }

      // // Example: read rows from 5 to 39
      // await readRows(5, 39);

      // console.log(nseArray);

      // below filter not working check it on tomorrow 07th Mar 2024

      // let latestNSEData = nseCircular;
      // let existingNSEData = nseArray;

      // let [, maxi] = existingNSEData[0][1].split("/");

      // let filtered = latestNSEData.filter((subArray) => {
      //   return subArray[1].split("/").slice(-1) > maxi;
      // });

      // if (filtered.length === 0) {
      //   // If array1 has a minimum range, console existingDPData as the filtered output
      //   console.log(existingNSEData);
      // } else {
      //   console.log(filtered);
      //   sortArr.push(filtered);
      // }

      // params.sort_nse_custom_arr = sortArr;

    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;
