const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { firefox } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("Source");
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.readRange("B2:B24");
      let Source = rslt.data.flat();

      rslt = await excelBot.readRange("D2:D24");
      let Url = rslt.data.flat();

      function geturl(source, url) {
        let result = source.map((el, index) => {
          return { sources: el, index, url: url[index] };
        });
        return result;
      }
      let connectUrl = geturl(Source, Url);
      console.log(connectUrl);
      rslt = await excelBot.readRange("A2:A24");
      let toMatch = rslt.data;
      // console.log(toMatch);

      const browser = await firefox.launch({
        headless: false,
        acceptDownloads: true,
      });

      const page = await browser.newPage();
      await page.goto(connectUrl[1].url);
      await util.wait(5000);

      // Header Data:
      const tableHeaders = await page.$$eval("table tbody tr th", (ths) =>
        ths.map((th) => th.textContent.trim())
      );
      console.log(tableHeaders);

      //Below to code to get only Text of Subject
      // Table Data
      const tableRowsData = await page.$$eval("table tbody tr tr", (rows) => {
        return rows.map((row) => {
          const cells = Array.from(row.querySelectorAll("td"));
          const rowData = cells.map((cell) => cell.textContent.trim());
          const hrefs = Array.from(row.querySelectorAll("a")).map((a) => a.getAttribute("href"));
          return { rowData, hrefs };
        });
      });

      // Remove the first two indexes
      const trimmedTableRowsData = tableRowsData.slice(2);

      console.log(trimmedTableRowsData);

      // Combine Header and Table Data:
      const combinedData = trimmedTableRowsData.map((rowData) => {
        const combinedRow = {};
        rowData.rowData.forEach((cell, index) => {
          combinedRow[tableHeaders[index]] = cell;
        });
        combinedRow['hrefs'] = rowData.hrefs.map(href => "https://www.bseindia.com" + href);
        return combinedRow;
      });

      console.log(combinedData);

    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;
