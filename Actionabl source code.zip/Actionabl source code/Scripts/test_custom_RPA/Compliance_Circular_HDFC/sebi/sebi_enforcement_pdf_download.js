const modules = global.modules;
const { CustomRPABase, util, Excel,bfs } = modules;
const { chromium } = modules.require("playwright");

const http = require("http");
const https = require("https");
const pdfParse = require("pdf-parse");


class webRPAScript extends CustomRPABase {
  async process() {
    try {
      //console.log("Url is :- " + url);
      const browser = await chromium.launch({ headless: false });
      const page = await browser.newPage();
      await page.goto("https://www.sebi.gov.in/sebiweb/home/HomeAction.do?doListingAll=yes", {
        waituntil: "load",
        timeout: 60000,
      });



      const elements = await page.waitForSelector(".points", { timeout: 0 });


      let circularTitles = await page.evaluate(() => {
        const titles = document.querySelectorAll(".points");
        return Array.from(titles).map((title) => title.innerText);
      });

      // console.log(circularTitles);

      const hrefs = await elements.evaluate(() => {
        const anchors = Array.from(
          document.querySelectorAll(".points")
        );
        const hrefSet = new Set(anchors.map((anchor) => anchor.href));
        return Array.from(hrefSet);
      });

      // console.log(hrefs);

      let circularRef = [];
      let circularDates = [];
      for(let i =0;i<hrefs.length;i++){
        await page.goto(hrefs[i], {  waituntil: "load", timeout: 60000, });


        // let layOutData = await page.evaluate(() => {
        //   const titles = document.querySelectorAll('#member-wrapper > section.department-slider.news_main.news-detail-slider > div.main_full.clearfix > section > div.m_section.bottom_space2 > div.id_area > span:nth-child(2)');
        //   return Array.from(titles).map((title) => title.innerText);
        // });

        let Dates = await page.evaluate(() => {
          const titles = document.querySelectorAll('#member-wrapper > section.department-slider.news_main.news-detail-slider > div.main_full.clearfix > section > div.m_section.bottom_space2 > div.date_value > h5');
          return Array.from(titles).map((title) => title.innerText);
        });

        // circularRef.push(layOutData[0])
        circularDates.push(Dates[0])

      }
      console.log(circularDates);
      console.log(circularRef);
      const data = circularTitles.map((title, index) => ({
        Subject: { value: title, href: "" },
        ["Circular Reference"]: { value: circularRef[index], href: "" },
        Date: { value: circularDates[index], href: "" },
      }));


      console.log(data);

      await browser.close()
      return {rc:0} ;

    } catch (e) {
      console.log(`Exception: ${e.message}`);
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
  async downloadFile(url, retries = 3) {
    return new Promise((resolve, reject) => {
      const retryRequest = (retryCount) => {
        const protocol = url.startsWith("https") ? https : http;
        protocol
          .get(url, (response) => {
            if (response.statusCode !== 200) {
              reject(
                new Error(
                  `Failed to download file, status code: ${response.statusCode}`
                )
              );
              return;
            }

            let chunks = [];

            // Append chunks of data as they arrive
            response.on("data", (chunk) => {
              chunks.push(chunk);
            });

            // Once all data has been received, resolve with the data
            response.on("end", () => {
              let data = Buffer.concat(chunks);

              resolve(data);

            });
          })
          .on("error", (error) => {
            if (retryCount > 0) {
              console.log(
                `Retrying Attempts left: ${retryCount} for url: ${url}`
              );
              setTimeout(() => {
                retryRequest(retryCount - 1);
              }, 1000);
            } else reject(error);
          });
      };
      retryRequest(retries);
    });

  }

}

module.exports = webRPAScript;
