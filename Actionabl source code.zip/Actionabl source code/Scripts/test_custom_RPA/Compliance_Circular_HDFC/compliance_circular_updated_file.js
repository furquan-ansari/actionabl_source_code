/* let modules = global.modules;
let { CustomRPABase, Excel } = modules;

class customRPA extends CustomRPABase {
  async process() {

    // Below code to compliance_email_sender
    // Below code to open file
    let self = this;
    let params = self.$;

      try{
        let excelBot = new Excel.bot();
        let rslt = await excelBot.init({ visible: true });
        let File = await excelBot.open(params.FilePath);
        // rslt = await excelBot.open('C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx');
        params.file = File;
        params.decision = true;

        if (rslt.rc != 0) return rslt;
        return { rc: 0 };
        }
        catch(e){
        console.log(e);
        }
  }

}
module.exports = customRPA;
 */

/////////////////////////////////////////////////////////////////////////

/* let modules = global.modules;
let { bfs, CustomRPABase } = modules;
const fs = modules.require("fs");

class customRPA extends CustomRPABase {
  async process() {
    let self = this;
    let params = self.$;
    let rslt;
    try {
      // let rslt = await bfs.readFile(params.FilePath);  // for dynamic value

    rslt = await fs.readFileSync(
        "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx"
      );

      let File = rslt;
      console.log(File);
      params.file = File;
      params.decision = true;

      return { rc: 0 };
    } catch (error) {
      console.log(error);
    }
    return { rc: 0 };
  }
}

module.exports = customRPA; */


//////////////////////////////////////////////////////////////////////////////

let modules = global.modules;
let { CustomRPABase, bfs} = modules;
// const format = modules.require("date-fns/format");

class customRPA extends CustomRPABase {
  async process() {
           // Below code to fetch data from file
        let self = this;
        let params = self.$;

        try{

          let filePath = "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx";
          let rslt = await bfs.fileExists(filePath);
          if (rslt.rc != 0) return rslt;

          let doesExist = rslt.data;
          params.file= filePath

          if(doesExist){
          let fileName ="Circulars_26-02-2024.xlsx";
          params.address=fileName

          console.log(filePath);
          console.log(fileName);

          params.decision = true;
          console.log("Attachment mail successfully sent to CC");

          }
          else{
            params.decision = false;
            console.log("Attachment mail failed to sent....");
            console.log("Reason: No file found at source Path");
          }




        // params.decision = false;

        return { rc: 0 };
        }
        catch(e){
          console.log(e);
        }

  }
}

module.exports = customRPA;
