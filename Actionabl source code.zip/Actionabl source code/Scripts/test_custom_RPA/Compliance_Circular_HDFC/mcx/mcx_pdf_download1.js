// const modules = global.modules;
// const { CustomRPABase, util, Excel } = modules;
// const { chromium } = modules.require("playwright");
// const { format } = modules.require("date-fns/format");

// class webRPAScript extends CustomRPABase {
//   async process() {
//     let self = this;
//     let rslt;
//     let params = self.$;
//     let sortArr = [];
//     try {
//       //       let excelBot = new Excel.bot();
//       //       rslt = await excelBot.init({ visible: true });
//       //       if (rslt.rc != 0) return rslt;

//       //       rslt = await excelBot.open(
//       //         "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
//       //       );
//       //       if (rslt.rc != 0) return rslt;
//       //       await util.wait(2000);

//       //       await excelBot.switchToSheet("Source");
//       //       if (rslt.rc != 0) return rslt;

//       //  /*      let nseLink;
//       //       let url = await excelBot.readCell("D3");
//       //       if (rslt.rc != 0) return rslt;
//       //       nseLink = url.data; */

//       //       rslt = await excelBot.readRange("B2:B24");
//       //       let Source = rslt.data.flat();

//       //       rslt = await excelBot.readRange("D2:D24");
//       //       let Url = rslt.data.flat();

//       //       function geturl (source, url){
//       //         let result = source.map((el,index)=>{
//       //           return {sources:el, index, url:url[index]}
//       //         });
//       //         return result;
//       //       }
//       //       let connectUrl = geturl(Source, Url);
//       //     //   console.log(connectUrl);
//       //       rslt = await excelBot.readRange('A2:A24');
//       //       let toMatch = rslt.data;
//       //       // console.log(toMatch);

//       //       const browser = await firefox.launch({
//       //         headless: false,
//       //         acceptDownloads: true,
//       //       });

//       //       const page = await browser.newPage();
//       //       await page.goto(connectUrl[1].url);
//       //       await util.wait(5000);

//       const browser = await chromium.launch({ headless: false });
//       const page = await browser.newPage();
//       await page.goto("https://www.mcxindia.com/circulars/all-circulars", {
//         waituntil: "load",
//         timeout: 10000,
//       });

//     //   const currentDate = new Date();
//     //   const today = format(currentDate, "dd/MM/yyyy");

//     //   let previousDay = new Date(currentDate);
//     //   previousDay.setDate(currentDate.getDate() - 5);
//     //   const PreviousDate = format(previousDay, "dd/MM/yyyy");


//     //   await page.locator("#txtToDate").fill(today);
//     //   await page.locator("#txtFromDate").fill(PreviousDate);
//     //   await page.click("#btnAdvance");

//     //   await util.wait(5000);

//     const currentDate = new Date();
//       const today = format(currentDate, "dd/MM/yyyy");

//       let previousDay = new Date(currentDate);
//       previousDay.setDate(currentDate.getDate() - 5);
//       const PreviousDate = format(previousDay, "dd/MM/yyyy");

//       function formatted_date({ fromDate, toDate }) {
//         const fromElement = document.getElementById("txtFromDate");
//         const toElement = document.getElementById("txtToDate");

//         fromElement.value = fromDate;
//         toElement.value = toDate;
//     }

//     //evaluate to call formatted_date function
//     await page.evaluate(formatted_date, { fromDate: PreviousDate, toDate: today });

//       //   let tableData = await page.$$eval("table tbody tr tr", (rows) => {
//       //     return rows.slice(2).map((row) => {
//       //       const cells = Array.from(row.querySelectorAll("td"));
//       //       const tableHeaders = ['Notice No', 'Subject', 'Segment Name', 'Category Name', 'Department'];
//       //       let rowData={};
//       //       cells.forEach((cell,index)=>{
//       //           let anchor = cell.querySelectorAll('a');
//       //           let href ="";
//       //           if(anchor.length>0){
//       //             href = "https://www.bseindia.com" +anchor[0].getAttribute('href');
//       //           }
//       //           if(tableHeaders[index] !=undefined)
//       //             rowData[tableHeaders[index]]={value:cell.textContent.trim(), href: href};
//       //       })

//       //       return rowData;
//       //     });
//       //   });

//       //   await page.locator('#ContentPlaceHolder1_GridView2 > tbody > tr.pgr > td > table > tbody > tr > td:nth-child(2) > a').click();

//       //   console.log(tableData);

//       // let allTableData = [];

//       // let hasNextPage = true;
//       // while (hasNextPage) {
//       //   let tableData = await page.$$eval("table tbody tr tr", (rows) => {
//       //     return rows.slice(2).map((row) => {
//       //       const cells = Array.from(row.querySelectorAll("td"));
//       //       const tableHeaders = ['Notice No', 'Subject', 'Segment Name', 'Category Name', 'Department'];
//       //       let rowData = {};
//       //       cells.forEach((cell, index) => {
//       //         let anchor = cell.querySelectorAll('a');
//       //         let href = "";
//       //         if (anchor.length > 0) {
//       //           href = "https://www.bseindia.com" + anchor[0].getAttribute('href');
//       //         }
//       //         if (tableHeaders[index] != undefined)
//       //           rowData[tableHeaders[index]] = { value: cell.textContent.trim(), href: href };
//       //       });

//       //       return rowData;
//       //     });
//       //   });

//       //   allTableData.push(tableData);

//       //   // Click on the next page link
//       //   const nextPageLink = await page.locator('#ContentPlaceHolder1_GridView2 > tbody > tr.pgr > td > table > tbody > tr > td:nth-child(2) > a');
//       //   if (nextPageLink) {
//       //     await nextPageLink.click();
//       //     // Assuming there's some delay after clicking the next page link
//       //     await page.waitForTimeout(2000); // Adjust the delay as per your requirement
//       //   } else {
//       //     hasNextPage = false; // No more next page link found, exit the loop
//       //   }
//       // }

//       // console.log(allTableData);

//       const pages = await page.locator(
//         "#tblCircular tbody tr"
//       );
//       console.log("number of pages", await pages.count());

//       for (let p = 0; p < (await pages.count()); p++) {
//         if (p > 0) {
//           await pages.nth(p).click();
//         }

//         let tableData = await page.$$eval("table tbody tr", (rows) => {
//           return rows.slice(2).map((row) => {
//             const cells = Array.from(row.querySelectorAll("td"));
//             const tableHeaders = [
//               "Date",
//               "Category",
//               "Title",
//               "Circular No.",
//             ];
//             let rowData = {};
//             cells.forEach((cell, index) => {
//               let anchor = cell.querySelectorAll("a");
//               let href = "";
//               if (anchor.length > 0) {
//                 href =
//                   "https://www.mcxindia.com" + anchor[0].getAttribute("href");
//               }
//               if (tableHeaders[index] != undefined)
//                 rowData[tableHeaders[index]] = {
//                   value: cell.textContent.trim(),
//                   href: href,
//                 };
//             });

//             return rowData;
//           });
//         });

//         //   await page.locator('#ContentPlaceHolder1_GridView2 > tbody > tr.pgr > td > table > tbody > tr > td:nth-child(2) > a').click();
//         await util.wait(1000);
//         console.log(tableData);
//       }
//     } catch (err) {
//       console.error(err.message);
//       console.error(err.stack);
//       throw err;
//     }
//     return { rc: 0 };
//   }
// }
// module.exports = webRPAScript;


///////////////////////////////////////////////////////////////////////////////////


const modules = global.modules;
const { bfs, CustomRPABase, util } = modules;
const { chromium } = modules.require('playwright');
const { format } = modules.require("date-fns/format");
// let modPath = require.resolve("../CircularExtractorBase");
// delete require.cache[modPath];
// const CircularExtractorBase = require(modPath);

class webRPAScript extends CustomRPABase {
    async process() {

      const browser = await chromium.launch({ headless: false });
        try {

            let browser = await chromium.launch({ headless: false });

            const page = await browser.newPage();
            await page.goto("https://www.mcxindia.com/circulars/all-circulars", { waituntil: 'load', timeout: 0 });

            const currentDate = new Date();
            const today = format(currentDate, 'dd/MM/yyyy')

            let previousDay = new Date(currentDate);
            previousDay.setDate(currentDate.getDate() - 20);
            const PreviousDate = format(previousDay, 'dd/MM/yyyy');

            // await page.locator('#txtFromDate').pressSequentially(PreviousDate);
            // await page.locator('#txtToDate').pressSequentially(today);

            function formatted_date({ fromDate, toDate }) {
                const fromElement = document.getElementById("txtFromDate");
                const toElement = document.getElementById("txtToDate");

                fromElement.value = fromDate;
                toElement.value = toDate;
            }

            //evaluate to call formatted_date function
            await page.evaluate(formatted_date, { fromDate: PreviousDate, toDate: today });

            await page.click('#btnAdvance');

            const pagerCount = await page.$eval("#pagerCount1", element => element.innerText);
            let webData = [];

            for (let i = 0; i < pagerCount; i++) {

                await page.waitForSelector('#tblCircular');

                let data = await page.$$eval("#tblCircular tbody tr", (rows) => {
                    return rows.map((row) => {
                        const cells = Array.from(row.querySelectorAll("td"));
                        const tableHeaders = ['Date', 'Category', 'Title', 'Circular No.'];
                        let rowData = {};
                        cells.forEach((cell, index) => {
                            let anchor = cell.querySelectorAll('a');
                            let href = "";
                            if (anchor.length > 0) {
                                href = anchor[0].getAttribute('href');
                            }
                            if (tableHeaders[index] != undefined)
                                rowData[tableHeaders[index]] = { value: cell.textContent.trim(), href: href };
                        })

                        return rowData;
                    });
                });
                webData.push(data);

                await page.click('#aNBCA');
            }
            console.log(webData);

        }
        catch (e) {
          await browser.close();
            console.warn(`Exception: ${e}`);
            return { rc: 1, msg: `Exception: ${e.message}` };
        }

    }

}

module.exports = webRPAScript;