const modules = global.modules;
const { CustomRPABase, util, Excel,bfs } = modules;
//let modPath = require.resolve("../CircularExtractorBase");
const { chromium } = modules.require("playwright");
//delete require.cache[modPath];
//const CircularExtractorBase = require(modPath);
const http = require("http");
const https = require("https");
const pdfParse = require("pdf-parse");

class webRPAScript extends CustomRPABase {
  async process() {
    try {
      //console.log("Url is :- " + url);
      const browser = await chromium.launch({ headless: false });
      const page = await browser.newPage();
      await page.goto("https://www.mcxindia.com/circulars/all-circulars", {
        waituntil: "load",
        timeout: 10000,
      });

    //   await page.selectOption(".filters-select", "2");

    //   const elements = await page.waitForSelector("#faq-2", { timeout: 0 });
      const elements = await page.waitForSelector("#tblCircular", { timeout: 0 });
      const hrefs = await elements.evaluate(() => {
        const anchors = Array.from(
          document.querySelectorAll("#tblCircular tbody tr td a")
        );
        const hrefSet = new Set(anchors.map((anchor) => anchor.href));
        return Array.from(hrefSet);
      });
      console.log(hrefs);
      console.log("///////////////////////////////////");
      // Title of circular
      let circularTitles = await page.evaluate(() => {
        const titles = document.querySelectorAll("#tblCircular tbody tr");
        return Array.from(titles).map((title) => {
          const titleElements = title.innerText.split('\t');
          return titleElements.length > 1 ? titleElements[2] : null;
        });
      });
      console.log(circularTitles.filter(title => title !== null));


    // let circularTitles = await page.evaluate(() => {
    //     const titles = document.querySelectorAll(
    //       "#tblCircular tbody tr td"
    //     );
    //     return Array.from(titles).map((title) => title.innerText);
    //   });
    //   console.log(circularTitles);


      let refArr = [];
      let cirDate = [];

    //   const regexPattern = /Circular no.: .*?\d{4}/g; //Regex for Reference Pattern
    //   const regexPattern = /Circular No\.: (\w+)\/(\w+)\/(\d+)\/(\d+)/g
    const regexPattern = /Circular (n|No).+\/\d{4}/g;
    const datePattern = /[A-z]+\s[0-9]{1,2}\W\s[0-9]{4}/gm; //Regex for Date Pattern


      for (let i = 0; i < hrefs.length; i++) {
        let data = await this.downloadFile(hrefs[i]); //Url of pdf to convert in buffer value
        let pdfData = await pdfParse(data); // Buffer value to convert in Text
        let circularRef = pdfData.text.match(regexPattern);
        let circularDate = pdfData.text.match(datePattern);

        cirDate.push(circularDate[0]);
        refArr.push(circularRef[0]);
        console.log("H");
      }

      // Convert Array to json format
      const data = circularTitles.map((title, index) => ({
        Subject: { value: title, href: "" },
        ["Circular Reference"]: { value: refArr[index], href: "" },
        Date: { value: cirDate[index], href: "" },
      }));

      await browser.close();
      console.log("MCX Completed");
      console.log(data);
      return data;

    } catch (e) {
      console.log(`Exception: ${e.message}`);
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
  async downloadFile(url, retries = 3) {
    return new Promise((resolve, reject) => {
      const retryRequest = (retryCount) => {
        const protocol = url.startsWith("https") ? https : http;
        protocol
          .get(url, (response) => {
            if (response.statusCode !== 200) {
              reject(
                new Error(
                  `Failed to download file, status code: ${response.statusCode}`
                )
              );
              return;
            }

            let chunks = [];

            // Append chunks of data as they arrive
            response.on("data", (chunk) => {
              chunks.push(chunk);
            });

            // Once all data has been received, resolve with the data
            response.on("end", () => {
              let data = Buffer.concat(chunks);

              resolve(data);

            });
          })
          .on("error", (error) => {
            if (retryCount > 0) {
              console.log(
                `Retrying Attempts left: ${retryCount} for url: ${url}`
              );
              setTimeout(() => {
                retryRequest(retryCount - 1);
              }, 1000);
            } else reject(error);
          });
      };
      retryRequest(retries);
    });
  }
}

module.exports = webRPAScript;
