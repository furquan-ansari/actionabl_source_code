// const modules = global.modules;
// const { CustomRPABase, util, Excel } = modules;
// const { firefox } = modules.require("playwright");

// class webRPAScript extends CustomRPABase {
//   async process() {
//     let self = this;
//     let rslt;
//     let params = self.$;
//     let sortArr = [];
//     try {
//       let excelBot = new Excel.bot();

//       rslt = await excelBot.init({ visible: true });
//       if (rslt.rc != 0) return rslt;

//       rslt = await excelBot.open(
//         "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
//       );
//       if (rslt.rc != 0) return rslt;
//       await util.wait(2000);

//       // await excelBot.switchToSheet("Source");
//       // if (rslt.rc != 0) return rslt;

//       let nsdlLink;
//       let url = await excelBot.readCell("D5");
//       if (rslt.rc != 0) return rslt;
//       nsdlLink = url.data;


//       // Below code used for dynamic
//    /*   rslt =  await excelBot.readRange("A1:L24");

//       if(rslt.rc != 0) return rslt;
//       let datas = rslt.data;

//       const headers= datas[0];

//       const jsonData = datas.slice(1).map(row =>{
//         const obj ={};
//         headers.forEach((header,index)=>{
//           obj[header] = row[index];
//         });
//         return obj;
//       })
// const jsonString = JSON.stringify(jsonData, null,2);
// console.log(jsonString); */




// /*       let complianceArray = [];

//       async function complianceReadRows(startRow, endRow) {
//         for (let row = startRow; row <= endRow; row++) {
//           rslt = await excelBot.readRange(`A${row}:L${row}`);
//           let rowData = rslt.data[0];

//           // Create an object for each row and add it to complianceArray
//           let rowObject = {};
//           rowData.forEach((value, index) => {
//             // Assuming you want to use column letters as keys (A, B, C, ..., L)
//             let columnLetter = String.fromCharCode(65 + index);
//             rowObject[columnLetter] = value;
//           });

//           complianceArray.push(rowObject);
//           console.log(rowObject);
//         }
//       }

//       // Example: read rows from 1 to 24
//       await complianceReadRows(1, 24);
//       let nsdlLink = complianceArray[4].D
//       console.log(nsdlLink); */


//      /*  let complianceDataArray = [];

// async function complianceReadRows(startRow, endRow, columnNames) {
//   for (let row = startRow; row <= endRow; row++) {
//     rslt = await excelBot.readRange(`A${row}:L${row}`);
//     let rowData = rslt.data[0];

//     // Create an object with keys based on dynamic column names
//     let rowObject = {};
//     columnNames.forEach((columnName, index) => {
//       rowObject[columnName] = rowData[index];
//     });

//     complianceDataArray.push(rowObject);
//     console.log(rowObject);
//   }
// }

// // Define the dynamic column names
// const dynamicColumnNames = ["column1", "column2", "column3","column4"];


// // Example: read rows from 1 to 24 with dynamic column names
// await complianceReadRows(1, 24, dynamicColumnNames); */



//       const browser = await firefox.launch({
//         headless: false,
//         acceptDownloads: true,
//       });
//       // const context = await browser.newContext();
//       // const page = await context.newPage();
//       const page = await browser.newPage();
//       await page.goto(nsdlLink);
//       await util.wait(5000);

//       const tableRowsData = await page.$$eval("table tbody tr", (rows) => {
//         return rows.map((row) => {
//           const cells = Array.from(row.querySelectorAll("td"));
//           return cells.map((cell) => cell.textContent.trim());
//         });
//       });
//       console.log(tableRowsData);

//       let data = tableRowsData;

//       function filterArrayByLatestDate(array) {
//         // Find the maximum date in the array
//         const latestDate = array.reduce((maxDate, item) => {
//           const currentDate = new Date(item[0]);
//           return currentDate > maxDate ? currentDate : maxDate;
//         }, new Date(0));

//         // Filter array based on the latest date
//         return array.filter(
//           (item) => new Date(item[0]).getTime() === latestDate.getTime()
//         );
//       }

//       // Example usage
//       const filteredData = filterArrayByLatestDate(data);
//       console.log(filteredData);

//       let latestDPData = filteredData;
//       // dpArr.push(filteredData);

//       // params.dparr = dpArr;

//       rslt = await excelBot.open(
//         // "C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\Circulars_20-02-2024.xlsx"
//         "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx"
//       );
//       if (rslt.rc != 0) return rslt;

//       await excelBot.switchToSheet("NSDL");
//       if (rslt.rc != 0) return rslt;

//       let dpArray = [];

//       async function readRows(startRow, endRow) {
//         for (let row = startRow; row <= endRow; row++) {
//           rslt = await excelBot.readRange(`C${row}:D${row}`);
//           let rowData = rslt.data[0];
//           dpArray.push(rowData);
//           console.log(rowData);
//         }
//       }

//       // Example: read rows from 5 to 8
//       await readRows(5, 8);

//       console.log(dpArray);

//       let existingDPData = dpArray;

//       let latestDateArray1 = new Date(
//         Math.max(...latestDPData.map((item) => new Date(item[0])))
//       );

//       // Find the latest date in array2
//       let latestDateArray2 = new Date(
//         Math.max(...existingDPData.map((item) => item[0].getTime()))
//       );

//       // Create a new array based on the comparison
//       let sortedArray = [];

//       if (latestDateArray1 > latestDateArray2) {
//         sortedArray = latestDPData;
//       } else {
//         sortedArray = existingDPData;
//       }

//       console.log(sortedArray);
//       sortArr.push(sortedArray);

//       params.sort_nsdl_dp_custom_arr = sortArr;
//     } catch (err) {
//       console.error(err.message);
//       console.error(err.stack);
//       throw err;
//     }
//     return { rc: 0 };
//   }
// }
// module.exports = webRPAScript;


///////////////////////////////////////////////////////////////////////////////


const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { firefox } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("Source");
      if (rslt.rc != 0) return rslt;


      // Below code used for getting  dynamic url from excel
      rslt = await excelBot.readRange("B2:B24");
      let Source = rslt.data.flat();

      rslt = await excelBot.readRange("D2:D24");
      let Url = rslt.data.flat();

      function geturl (source, url){
        let result = source.map((el,index)=>{
          return {sources:el, index, url:url[index]}
        });
        return result;
      }
      let connectUrl = geturl(Source, Url);
      console.log("Below array for URL getting from Excel sheet>>>>>>");
      console.log(connectUrl);
      rslt = await excelBot.readRange('A2:A24');
      let toMatch = rslt.data;
      // console.log(toMatch);


      const browser = await firefox.launch({
        headless: false,
        acceptDownloads: true,
      });

      const page = await browser.newPage();
      await page.goto(connectUrl[3].url)
      await util.wait(5000);

      const tableRowsData = await page.$$eval("table tbody tr", (rows) => {
        return rows.map((row) => {
          const cells = Array.from(row.querySelectorAll("td"));
          return cells.map((cell) => cell.textContent.trim());
        });
      });
      console.log("Below array for table row data getting from NSDL Site>>>>>>");
      console.log(tableRowsData);

      let data = tableRowsData;

      function filterArrayByLatestDate(array) {
        // Find the maximum date in the array
        const latestDate = array.reduce((maxDate, item) => {
          const currentDate = new Date(item[0]);
          return currentDate > maxDate ? currentDate : maxDate;
        }, new Date(0));

        // Filter array based on the latest date
        return array.filter(
          (item) => new Date(item[0]).getTime() === latestDate.getTime()
        );
      }

      // Example usage
      const filteredData = filterArrayByLatestDate(data);
      console.log("Below array for table row data getting from NSDL Site and filter according to latest Date >>>>>>");
      console.log(filteredData);

      let latestDPData = filteredData;

      rslt = await excelBot.open(
       "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx"
      );
      if (rslt.rc != 0) return rslt;

      await excelBot.switchToSheet("NSDL");
      if (rslt.rc != 0) return rslt;

      let dpArray = [];

      async function readRows(startRow, endRow) {
        for (let row = startRow; row <= endRow; row++) {
          rslt = await excelBot.readRange(`C${row}:D${row}`);
          let rowData = rslt.data[0];
          dpArray.push(rowData);
          // console.log(rowData);
        }
      }

      // Example: read rows from 5 to 8
      await readRows(5, 8);
      console.log("Below array for table row data getting from circular excel of NSDL DP data>>>>>>");
      console.log(dpArray);

      let existingDPData = dpArray;

      let latestDateArray1 = new Date(
        Math.max(...latestDPData.map((item) => new Date(item[0])))
      );

      // Find the latest date in array2
      let latestDateArray2 = new Date(
        Math.max(...existingDPData.map((item) => item[0].getTime()))
      );

      // Create a new array based on the comparison
      let sortedArray = [];

      if (latestDateArray1 > latestDateArray2) {
        sortedArray = latestDPData;
      } else {
        sortedArray = existingDPData;
      }
      console.log("Below array for final sorted Array after performing sorting operation>>>>>>");
      console.log(sortedArray);
      sortArr.push(sortedArray);

      params.sort_nsdl_dp_custom_arr = sortArr;
    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;
