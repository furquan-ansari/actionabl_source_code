const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { firefox } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("Source");
      if (rslt.rc != 0) return rslt;

           // Below code used for getting  dynamic url from excel
           rslt = await excelBot.readRange("B2:B24");
           let Source = rslt.data.flat();

           rslt = await excelBot.readRange("D2:D24");
           let Url = rslt.data.flat();

           function geturl (source, url){
             let result = source.map((el,index)=>{
               return {sources:el, index, url:url[index]}
             });
             return result;
           }
           let connectUrl = geturl(Source, Url);
           console.log("Below array for URL getting from Excel sheet>>>>>>");
           console.log(connectUrl);
           rslt = await excelBot.readRange('A2:A24');
           let toMatch = rslt.data;
           // console.log(toMatch);


      const browser = await firefox.launch({
        headless: false,
        acceptDownloads: true,
      });

      const page = await browser.newPage();
      await page.goto(connectUrl[4].url)
      await util.wait(5000);

      // let tableData = await page.$$eval("table tbody tr ", (rows) => {
      //   return rows.slice(8).map((row) => {
      //     const cells = Array.from(row.querySelectorAll("td"));
      //     const tableHeaders = ['Date','Title'];
      //     let rowData={};
      //     cells.forEach((cell,index)=>{
      //         let anchor = cell.querySelectorAll('a');
      //         let href ="";
      //         if(anchor.length>0){
      //           href = "https://nsdl.co.in" +anchor[0].getAttribute('href');
      //         }
      //         if(tableHeaders[index] !=undefined)
      //           rowData[tableHeaders[index]]={value:cell.textContent.trim(), href: href};
      //     })

      //     return rowData;
      //   });
      // });
      // let data={RTA:tableData}
      // console.log(data);

///////////////////////////////////////////////////////////////////////


let tableData = await page.$$eval("table tbody tr ", (rows) => {
  return rows.slice(8).map((row) => {
      const cells = Array.from(row.querySelectorAll("td"));
      const tableHeaders = ['Date', 'Title'];
      let rowData = {};
      cells.forEach((cell, index) => {
          let anchor = cell.querySelectorAll('a');
          let href = "";
          if (anchor.length > 0) {
              href = "https://nsdl.co.in" + anchor[0].getAttribute('href');
          }
          if (tableHeaders[index] != undefined)
              rowData[tableHeaders[index]] = { value: cell.textContent.trim(), href: href };
      });

      return rowData;
  }).filter(row => 'Title' in row); // Filter out rows that don't have the 'Title' key
});
let data = { RTA: tableData };
console.log(data);



///////////////////////////////////////////////////////////////////////

//       const tableRowsData = await page.$$eval("table tbody tr", (rows) => {
//         return rows.map((row) => {
//           const cells = Array.from(row.querySelectorAll("td"));
//           return cells.map((cell) => cell.textContent.trim());
//         });
//       });
//       console.log("Below array for table row data getting from NSDL Site>>>>>>");

//       console.log(tableRowsData);

//       let data = tableRowsData;

//       function filterArrayByLatestDate(array) {
//         // Find the maximum date in the array
//         const latestDate = array.reduce((maxDate, item) => {
//           const currentDate = new Date(item[0]);
//           return currentDate > maxDate ? currentDate : maxDate;
//         }, new Date(0));

//         // Filter array based on the latest date
//         return array.filter(
//           (item) => new Date(item[0]).getTime() === latestDate.getTime()
//         );
//       }

//       // Example usage
//       const filteredData = filterArrayByLatestDate(data);
//       console.log("Below array for table row data getting from NSDL Site and filter according to latest Date >>>>>>");
//       console.log(filteredData);

//       let latestRTAData = filteredData;


//       rslt = await excelBot.open(
//   "C:\\Users\\Furquan\\compliance_circular_data\\Fwd Reference sheet\\Circulars_26-02-2024.xlsx"
//       );
//       if (rslt.rc != 0) return rslt;

//       await excelBot.switchToSheet("NSDL");
//       if (rslt.rc != 0) return rslt;

//       let rtaArray = [];

//       async function readRows(startRow, endRow) {
//         for (let row = startRow; row <= endRow; row++) {
//           rslt = await excelBot.readRange(`C${row}:D${row}`);
//           let rowData = rslt.data[0];
//           rtaArray.push(rowData);
//           // console.log(rowData);
//         }
//       }

//       // Example: read rows from 11 to 12
//       await readRows(11, 12);
//       console.log("Below array for table row data getting from circular excel of NSDL RTA data>>>>>>");
//       console.log(rtaArray);

//       let existingRTAData = rtaArray;

//       let latestDateArray1 = new Date(
//         Math.max(...latestRTAData.map((item) => new Date(item[0])))
//       );

//       // Find the latest date in array2
//       let latestDateArray2 = new Date(
//         Math.max(...existingRTAData.map((item) => item[0].getTime()))
//       );

//       // Create a new array based on the comparison
//       let sortedArray = [];

//       if (latestDateArray1 > latestDateArray2) {
//         sortedArray = latestRTAData;
//       } else {
//         sortedArray = existingRTAData;
//       }

//       console.log("Below array for final sorted Array after performing sorting operation>>>>>>");
//       console.log(sortedArray);
//       sortArr.push(sortedArray);

//       params.sort_nsdl_rta_custom_arr = sortArr;
    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;
