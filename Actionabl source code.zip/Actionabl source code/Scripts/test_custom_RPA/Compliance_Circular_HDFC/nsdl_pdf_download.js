const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { firefox } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
      "C:\\Users\\LENOVO\\Downloads\\Circulars_05-04-2024.xlsx"
        );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("NSDL");
      if (rslt.rc != 0) return rslt;

      let pdfLink = await excelBot.readRange("D2:D5");

      console.log(pdfLink.data);

      const browser = await firefox.launch({
            headless: false,
            acceptDownloads: true,
          });

          const page = await browser.newPage();
          await page.goto(pdfLink[0])
          await util.wait(5000);

    //   // Below code used for getting  dynamic url from excel
    //   rslt = await excelBot.readRange("B2:B24");
    //   let Source = rslt.data.flat();

    //   rslt = await excelBot.readRange("D2:D24");
    //   let Url = rslt.data.flat();

    //   function geturl (source, url){
    //     let result = source.map((el,index)=>{
    //       return {sources:el, index, url:url[index]}
    //     });
    //     return result;
    //   }
    //   let connectUrl = geturl(Source, Url);
    //   // console.log("Below array for URL getting from Excel sheet>>>>>>");
    //   // console.log(connectUrl);
    //   rslt = await excelBot.readRange('A2:A24');
    //   let toMatch = rslt.data;
    //   // console.log(toMatch);


    //   const browser = await firefox.launch({
    //     headless: false,
    //     acceptDownloads: true,
    //   });

    //   const page = await browser.newPage();
    //   await page.goto(connectUrl[3].url)
    //   await util.wait(5000);


    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;