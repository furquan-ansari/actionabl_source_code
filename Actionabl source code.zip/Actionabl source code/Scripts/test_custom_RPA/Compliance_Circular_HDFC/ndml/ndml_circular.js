const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { chromium } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      let excelBot = new Excel.bot();
      rslt = await excelBot.init({ visible: true });
      if (rslt.rc != 0) return rslt;

      rslt = await excelBot.open(
        "C:\\Users\\Furquan\\compliance_circular_data\\Compliance_Automation_of_circulars.xlsx"
      );
      if (rslt.rc != 0) return rslt;
      await util.wait(2000);

      await excelBot.switchToSheet("Source");
      if (rslt.rc != 0) return rslt;


      // Below code used for getting  dynamic url from excel
      rslt = await excelBot.readRange("B2:B24");
      let Source = rslt.data.flat();

      rslt = await excelBot.readRange("D2:D24");
      let Url = rslt.data.flat();

      function geturl (source, url){
        let result = source.map((el,index)=>{
          return {sources:el, index, url:url[index]}
        });
        return result;
      }
      let connectUrl = geturl(Source, Url);
      console.log("Below array for URL getting from Excel sheet>>>>>>");
      console.log(connectUrl);
      rslt = await excelBot.readRange('A2:A24');
      let toMatch = rslt.data;
      // console.log(toMatch);


      const browser = await chromium.launch({
        headless: false,
        acceptDownloads: true,
      });

      const page = await browser.newPage();
      await page.goto(connectUrl[18].url)
      await util.wait(5000);

      

      await page.selectOption('.filters-select', '2');

      let a = await page.waitForSelector('#faq-2');
      let webData = await a.$$eval('span', a => {
      return a.map(span => span.innerText);
            })
    //  console.log(webData);

    // Below code to open new tab
    await page.click('//*[@id="faq-2"]/div/div/div[1]/span[2]/a[1]');
    await page.waitForLoadState();

    let url =  page.url()
    console.log(url);
    


    // To download pdf documentation
    // await page.click('//*[@id="download"]');
    // await page.waitForLoadState();

    // Start waiting for download before clicking. Note no await.
// const downloadPromise = page.waitForEvent('download');
// // await page.click('//*[@id="download"]');
// await page.getByText('Download').click();
// const download = await downloadPromise;

// Wait for the download process to complete and save the downloaded file somewhere.
// await download.saveAs('C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\NDML/' + download.suggestedFilename());

    //  const p = page.waitForEvent('page');
    //  console.log(p);
    //  await page.click('//*[@id="faq-2"]/div/div/div[1]/span[2]/a[1]');
    // const newPage = await p;
    // await page.waitForLoadState();
    // let pdfUrl = await page.url();
    // await util.wait(5000)


    //  function downloadFile(fileName) {
    //   // Set the File URL.
    //   var url = "Files/" + fileName;

      // Create XMLHTTP Request.
      // var req = new XMLHttpRequest();
      // req.open("GET", pdfUrl, true);
      // req.responseType = "blob";
      // req.onload = function () {
      //     // Convert the Byte Data to BLOB object.
      //     var blob = new Blob([req.response], { type: "application/octetstream" });

      //     // Check the Browser type and download the File.
      //     var isIE = false || !!document.documentMode;
      //     if (isIE) {
      //         window.navigator.msSaveBlob(blob, fileName);
      //     } else {
      //         // Prompt the user to select a location using the browser's file save dialog.
      //         var a = document.createElement("a");
      //         a.setAttribute("download", fileName);
      //         a.setAttribute("href", window.URL.createObjectURL(blob));
      //         a.style.display = "none";
      //         document.body.appendChild(a);
      //         a.click();
      //         document.body.removeChild(a);
      //     }
      // };
      //req.send();
  //};


// Start waiting for download before clicking. Note no await.
// const downloadPromise = page.waitForEvent('download');
// await page.getByText('Download').click();
// const download = await downloadPromise;

// // Wait for the download process to complete and save the downloaded file somewhere.
// await download.saveAs('C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\NDML/' + download.suggestedFilename());

    //  await page.locator('*[@id="faq-2"]/div/div/div[1]/span[2]/a[1]').click();
    //  console.log(b);

    //  await page.waitForEvent('popup');
      // const downloadPromise = await page.waitForEvent('View');
      // await page.locator('.clickers').first().click();
      // const download = await downloadPromise;
      // await util.wait(2000);
      // await download.saveAs('C:\\Users\\Furquan\\compliance_circular_data\\Downloaded_Circular\\NDML/' + download.suggestedFilename());
      // console.log("success");


    //   sortArr.push(sortedArray);
    //   params.sort_nsdl_dp_custom_arr = sortArr;
    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;