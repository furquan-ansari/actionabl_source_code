const modules = global.modules;
const { CustomRPABase, util, Excel } = modules;
const { chromium } = modules.require("playwright");

class webRPAScript extends CustomRPABase {
  async process() {
    let self = this;
    let page = self;
    let rslt;
    let params = self.$;
    let sortArr = [];
    try {
      await page.goto('https://ndml.in/circulars.php')
      await util.wait(5000);

      await page.selectOption('.filters-select', '2');

      let a = await page.waitForSelector('#faq-2');
      let webData = await a.$$eval('span', a => {
      return a.map(span => span.innerText);
            })
    //  console.log(webData);

    // Below code to open new tab
    await page.click('//*[@id="faq-2"]/div/div/div[1]/span[2]/a[1]');
    await page.waitForLoadState();

    let url =  page.url()
    console.log(url);


    } catch (err) {
      console.error(err.message);
      console.error(err.stack);
      throw err;
    }
    return { rc: 0 };
  }
}
module.exports = webRPAScript;