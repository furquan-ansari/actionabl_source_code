const modules = global.modules;
const { CustomRPABase, util, Excel,bfs } = modules;
//let modPath = require.resolve("../CircularExtractorBase");
const { firefox } = modules.require("playwright");
//delete require.cache[modPath];
//const CircularExtractorBase = require(modPath);
const http = require("http");
const https = require("https");
const pdfParse = require("pdf-parse");

class webRPAScript extends CustomRPABase {
  async process() {
    try {
      //console.log("Url is :- " + url);
      const browser = await firefox.launch({ headless: false });
      const page = await browser.newPage();
      await page.goto("https://www.nseindia.com/resources/exchange-communication-circulars", {
        waituntil: "load",
        timeout: 10000,
      });

    //   await page.selectOption(".filters-select", "2");

    //   const elements = await page.waitForSelector("#faq-2", { timeout: 0 });
      const elements = await page.waitForSelector("#CircularTable", { timeout: 0 });
      const hrefs = await elements.evaluate(() => {
        const anchors = Array.from(
          document.querySelectorAll("#CircularTable  tbody  a")
        );
        const hrefSet = new Set(anchors.map((anchor) => anchor.href));
        return Array.from(hrefSet);
      });
      // console.log(hrefs);
      let sortedArr =[]
      hrefs.map(arr=>{
        if(arr.includes('.pdf')){
          sortedArr.push(arr)
        }
      })
      console.log(sortedArr);
      console.log("///////////////////////////////////");
      // Title of circular
      let circularTitles = await page.evaluate(() => {
        const titles = document.querySelectorAll("#CircularTable tbody tr");
        return Array.from(titles).map((title) => {
          const titleElements = title.innerText.split('\t');
          return titleElements.length > 1 ? titleElements[1] : null;
        });
      });
      // console.log(circularTitles.filter(title => title !== null));


      // let circularTitles = await page.evaluate(() => {
      //   const titles = document.querySelectorAll(
      //     "#CircularTable tbody"
      //   );
      //   return Array.from(titles).map((title) => title.innerText.split('\t'))
      // });
      // console.log(circularTitles);

      let refArr = [];
      let cirDate = [];

      // const regexPattern = /Download Ref No: .*?\d{5}/g; //Regex for Reference Pattern
      // const regexPattern = /Download Ref No:\s*(\S*?)(?=\s*\d{5}\b)/g
      const regexPattern = /Download+\d{5}/g;
      const datePattern = /[A-z]+\s[0-9]{1,2}\W\s[0-9]{4}/gm; //Regex for Date Pattern

      for (let i = 0; i < sortedArr.length; i++) {
        let data = await this.downloadFile(sortedArr[i]); //Url of pdf to convert in buffer value
        let pdfData = await pdfParse(data); // Buffer value to convert in Text
        let circularRef = pdfData.text.match(regexPattern);
        let circularDate = pdfData.text.match(datePattern);

        cirDate.push(circularDate[0]);
        refArr.push(circularRef[0]);

      }
      console.log(cirDate);
      console.log(refArr);

      // Convert Array to json format
      const data = circularTitles.map((title, index) => ({
        Subject: { value: title, href: "" },
        ["Circular Reference"]: { value: refArr[index], href: "" },
        Date: { value: cirDate[index], href: "" },
      }));

      console.log(data);
      console.log("NSE Completed");
      await browser.close();
      return {rc : 0}

    } catch (e) {
      console.log(`Exception: ${e.message}`);
      return { rc: 1, msg: `Exception: ${e.message}` };
    }
  }
  async downloadFile(url, retries = 3) {
    return new Promise((resolve, reject) => {
      const retryRequest = (retryCount) => {
        const protocol = url.startsWith("https") ? https : http;
        protocol
          .get(url, (response) => {
            if (response.statusCode !== 200) {
              reject(
                new Error(
                  `Failed to download file, status code: ${response.statusCode}`
                )
              );
              return;
            }

            let chunks = [];

            // Append chunks of data as they arrive
            response.on("data", (chunk) => {
              chunks.push(chunk);
            });

            // Once all data has been received, resolve with the data
            response.on("end", () => {
              let data = Buffer.concat(chunks);

              resolve(data);

            });
          })
          .on("error", (error) => {
            if (retryCount > 0) {
              console.log(
                `Retrying Attempts left: ${retryCount} for url: ${url}`
              );
              setTimeout(() => {
                retryRequest(retryCount - 1);
              }, 1000);
            } else reject(error);
          });
      };
      retryRequest(retries);
    });
  }
}

module.exports = webRPAScript;
