let modules = global.modules;
let { CustomRPABase, Excel, util } = modules;
const playwright = modules.require("playwright");

class CustomRPA extends CustomRPABase {
  async process() {
    let self = this;
    let $ = self.$;

    try {
      const browser = await playwright.chromium.launch({
        channel: "msedge",
        headless: false,
      });
      const context = await browser.newContext();
      const page = await context.newPage();
      await page.goto("https://www.nseindia.com/all-reports");

      //   To select Archives
      await page.locator('[id="Archives_rpt"]').selectText();
      await page.locator('[id="Archives_rpt"]').click();

      //  To Open Calender

      await page.locator('[id="cr_equity_archives_date"]').selectText();
      await page.locator('[id="cr_equity_archives_date"]').click();

      //  To select current Date
      // const currentData = '01-Jan-2024'    // Hard Coded;
      let currentDate = new Date();
      let selectedDate = currentDate.toLocaleDateString();
      console.log(selectedDate);

      const datePickerFunc = (selectedDate) => {
        document.getElementById("cr_equity_archives_date").value = selectedDate;
      };

      // Call the function using evaluate method
      await page.evaluate(datePickerFunc, selectedDate);

      await util.wait(2000);

      /* await page
        .locator('cond={type:"div", str:"9",actionablId: "5058"}')
        .selectText();
        await page
        .locator('cond={type:"div", str:"9",actionablId: "5058"}')
        .click();
        await util.wait(2000); */

      /* await page
.locator('[class="today gj-cursor-pointer selected"]')
.selectText();
await page
.locator('[class="today gj-cursor-pointer selected"]')
.click(); */

      /*   await page
        .locator('[id": "cr_equity_archives_dateLbl"]')
        .selectText();
      await page
        .locator('[id": "cr_equity_archives_dateLbl"]')
        .click(); */

      // cond={type:'div', str:'9'}
      // 'cond={id:"cnt", type:"span"}'

      return { rc: 0 };
    } catch (e) {
      console.log("Exception Message :- " + e.Message);
      // return { rc : 1,Message : e.Message}
    }
  }
}

module.exports = CustomRPA;
