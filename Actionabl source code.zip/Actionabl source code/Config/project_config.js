let conf = {
    app: {
        agent_id: 'published'
    },
    system: {
        simulation_mode: false,
        debug_mode: false
    },
    db: {
        host: 'localhost',
        user: 'admin',
        database: 'actionabl'
    },
    db_setup: {
        run_setup: false,
        recreate: false
    },
    component_cluster_setup: {
        default: 'nsdl_dp_pdf_download',
        nsdl_dp_pdf_download:true,
        sebi_reports_pdf_download:true,
        sebi_media_pdf_download:true,
        sebi_enforcement_pdf_download:true,
        nps_pdf_donwload: true,
        compliance_bse:true,
        mcx_pdf_download:true,
        nse_pdf_download:true,
        ndml_pdf_download:true,
        nsdl_pdf_download_win:true,
        nsdl_pdf_download:true,
        test:true,
        compliance_cdsl_dp:true,
        compliance_cdsl_rta:true,
        compliance_nsdl_dp: true,
        compliance_nsdl_rta:true,
        compliance_amfi: true,
        excel_extraction:true,
        connect_window:true,
        test_recaptcha:true,
        compliance_linear_email_sender: true,
        compliance_email_sender: true,
        compliance_ndml:true,
        compliance_nse:true,
        nsdl_circular_dp_web:true,
        multiEmailSender2:true,
        multiEmailSender3:true,
        multiEmailSender1:true,
        multiEmailSender:true,
        logfile_emailtask: true,
        rpaExcelInputForms:true,
        rpachallengeinputforms:true,
        readfile: true,
        readfilelinear:true,
        read_dir: true,
        create_dir:true,
        copy_dir:true,
        delete_dir:true,
        volume_sms_process: true,
        exchange_file_receipt_process: true,
        cml_email_request: true,
        bod_import: true,
        contract_note_printing_process: true
    },
    jobs: {
        default_max_task_attempts: 1,
        default_run_interval: 60000,
        poke_interval: 60000,
        cronProcessor: { start: false }
    },
    security: {
        encrypt_repository: false,
        encrypt_data: false,
        password_expiry_period: '99y',
        password_reset_link_expiry_period: '2h',
        pwd_history_check: 2,
        action_link_expiry_period: '30d',
        session_max_idle_time: 1800,
        session_check_frequency: 600,
    },
    rpa: {
        web: {
            browser_type: 'chromium',
            headless: false,
            accept_downloads: false,
            store_state: false,
        },
        win_snapshot_mode: 2,
    },
    mailgen: {
        theme: 'default',
        product: {}
    },
};

module.exports = conf;